(function() {
    let retryCount = 0;
    const maxRetries = 30; // 30 retries max
    let cartElement = null;
    let storeElement = null;
    let badgeObserver = null;
    let eventListenersAttached = false;
    let pollingInterval = null;

    /**
     * Gets the cart quantity using multiple methods
     */
    function getCartQuantity(cart, store) {
        let quantity = 0;
        
        try {
            // Method 1: Try store.getCart() - Shopify Storefront API (may be async)
            if (store && typeof store.getCart === 'function') {
                try {
                    const cartData = store.getCart();
                    // Check if it's a Promise
                    if (cartData && typeof cartData.then === 'function') {
                        // It's async - handle it in the async version
                        // For now, continue to other methods
                    } else if (cartData && cartData.lines) {
                        quantity = cartData.lines.reduce((sum, line) => sum + (line.quantity || 0), 0);
                        if (quantity > 0) {
                            console.log('[CartIcon] ✅ Got quantity from store.getCart():', quantity);
                            return quantity;
                        }
                    }
                } catch (e) {
                    // getCart might be async, ignore
                }
            }

            // Method 2: Try store.cart property
            if (store && store.cart) {
                if (store.cart.lines && Array.isArray(store.cart.lines)) {
                    quantity = store.cart.lines.reduce((sum, line) => sum + (line.quantity || 0), 0);
                    if (quantity > 0) {
                        console.log('[CartIcon] ✅ Got quantity from store.cart.lines:', quantity);
                        return quantity;
                    }
                }
                if (store.cart.totalQuantity !== undefined && store.cart.totalQuantity !== null) {
                    quantity = store.cart.totalQuantity;
                    if (quantity > 0) {
                        console.log('[CartIcon] ✅ Got quantity from store.cart.totalQuantity:', quantity);
                        return quantity;
                    }
                }
            }

            // Method 3: Try cart element's shadowRoot for cart data
            if (cart && cart.shadowRoot) {
                // Strategy 1: Directly find all quantity labels (most reliable, avoids double counting)
                const quantityLabels = cart.shadowRoot.querySelectorAll('[data-testid="quantity-label"]');
                if (quantityLabels.length > 0) {
                    let totalQty = 0;
                    quantityLabels.forEach(label => {
                        const qtyText = label.textContent?.trim();
                        const qty = parseInt(qtyText, 10);
                        if (!isNaN(qty) && qty > 0) {
                            totalQty += qty;
                        }
                    });
                    if (totalQty > 0) {
                        quantity = totalQty;
                        console.log('[CartIcon] ✅ Got quantity from cart shadowRoot quantity labels sum:', quantity, '(from', quantityLabels.length, 'labels)');
                        return quantity;
                    }
                }
                
                // Strategy 2: Find line item containers (fallback - only use container, not child)
                const lineItems = cart.shadowRoot.querySelectorAll('.line-item-container');
                if (lineItems.length > 0) {
                    let totalQuantity = 0;
                    
                    lineItems.forEach(lineItem => {
                        // Try multiple ways to find the quantity in each line item
                        // Priority: data-testid="quantity-label" is the most reliable
                        const qtySelectors = [
                            '[data-testid="quantity-label"]',
                            '[data-quantity]',
                            '.quantity',
                            '[data-line-quantity]',
                            'input[type="number"]',
                            'input[type="text"][value]',
                            '[part="quantity"]',
                            'input.quantity-input',
                            'input[aria-label*="quantity" i]'
                        ];
                        
                        let lineQty = 0;
                        for (const selector of qtySelectors) {
                            const qtyEl = lineItem.querySelector(selector);
                            if (qtyEl) {
                                // Try textContent first
                                let qtyText = qtyEl.textContent?.trim();
                                // If it's an input, try value attribute
                                if (!qtyText && qtyEl.value !== undefined) {
                                    qtyText = qtyEl.value;
                                }
                                // Try data attributes
                                if (!qtyText) {
                                    qtyText = qtyEl.getAttribute('data-quantity') || 
                                             qtyEl.getAttribute('data-line-quantity') ||
                                             qtyEl.getAttribute('value');
                                }
                                
                                const qty = parseInt(qtyText, 10);
                                if (!isNaN(qty) && qty > 0) {
                                    lineQty = qty;
                                    break; // Found quantity for this line, move to next
                                }
                            }
                        }
                        
                        // If we couldn't find quantity in the line item, check if the line item itself has numeric text
                        if (lineQty === 0) {
                            const lineText = lineItem.textContent?.trim();
                            // Look for a number that's likely a quantity (1-99, not a price)
                            const match = lineText?.match(/\b([1-9]\d?)\b/);
                            if (match) {
                                const potentialQty = parseInt(match[1], 10);
                                // Only use if it's a reasonable quantity (1-99)
                                if (potentialQty > 0 && potentialQty < 100) {
                                    lineQty = potentialQty;
                                }
                            }
                        }
                        
                        totalQuantity += lineQty;
                    });
                    
                    if (totalQuantity > 0) {
                        quantity = totalQuantity;
                        console.log('[CartIcon] ✅ Got quantity from cart shadowRoot line items sum:', quantity, '(from', lineItems.length, 'line items)');
                        return quantity;
                    }
                    
                    // Fallback: if we found line items but couldn't extract quantities, count them
                    quantity = lineItems.length;
                    console.log('[CartIcon] ✅ Got quantity from cart shadowRoot line items count (fallback):', quantity);
                    return quantity;
                }
                
                // Strategy 3: Look for total quantity display element
                const quantityElement = cart.shadowRoot.querySelector('[data-cart-count], .cart-count, [data-quantity], [data-total-quantity], [data-total-items]');
                if (quantityElement) {
                    const quantityText = quantityElement.textContent?.trim() || 
                                        quantityElement.getAttribute('data-quantity') || 
                                        quantityElement.getAttribute('data-cart-count') ||
                                        quantityElement.getAttribute('data-total-quantity');
                    const parsed = parseInt(quantityText, 10);
                    if (!isNaN(parsed) && parsed > 0) {
                        quantity = parsed;
                        console.log('[CartIcon] ✅ Got quantity from cart shadowRoot total element:', quantity);
                        return quantity;
                    }
                }
            }

            // Method 4: Try cart.cart property
            if (cart && cart.cart) {
                if (cart.cart.lines && Array.isArray(cart.cart.lines)) {
                    quantity = cart.cart.lines.reduce((sum, line) => sum + (line.quantity || 0), 0);
                    if (quantity > 0) {
                        console.log('[CartIcon] ✅ Got quantity from cart.cart.lines:', quantity);
                        return quantity;
                    }
                }
                if (cart.cart.totalQuantity !== undefined && cart.cart.totalQuantity !== null) {
                    quantity = cart.cart.totalQuantity;
                    if (quantity > 0) {
                        console.log('[CartIcon] ✅ Got quantity from cart.cart.totalQuantity:', quantity);
                        return quantity;
                    }
                }
            }

            // Method 5: Try cart.state property
            if (cart && cart.state) {
                if (cart.state.lines && Array.isArray(cart.state.lines)) {
                    quantity = cart.state.lines.reduce((sum, line) => sum + (line.quantity || 0), 0);
                    if (quantity > 0) {
                        console.log('[CartIcon] ✅ Got quantity from cart.state.lines:', quantity);
                        return quantity;
                    }
                }
            }

            // Method 6: Try direct properties on cart
            if (cart) {
                if (cart.totalQuantity !== undefined && cart.totalQuantity !== null) {
                    quantity = cart.totalQuantity;
                    if (quantity > 0) {
                        console.log('[CartIcon] ✅ Got quantity from cart.totalQuantity:', quantity);
                        return quantity;
                    }
                }
                if (cart.quantity !== undefined && cart.quantity !== null) {
                    quantity = cart.quantity;
                    if (quantity > 0) {
                        console.log('[CartIcon] ✅ Got quantity from cart.quantity:', quantity);
                        return quantity;
                    }
                }
            }

            // Method 7: Query Storefront API directly via localStorage (Shopify stores cart ID there)
            try {
                const cartId = localStorage.getItem('cart') || localStorage.getItem('shopify-cart-id');
                if (cartId && store && store.storeDomain) {
                    // We could fetch here, but it's async - we'll use polling for this
                }
            } catch (e) {
                // Ignore localStorage errors
            }

            return 0;
        } catch (error) {
            console.warn('[CartIcon] Error getting cart quantity:', error);
            return 0;
        }
    }

    /**
     * Async version to get cart quantity (for Promise-based APIs)
     */
    async function getCartQuantityAsync(cart, store) {
        try {
            // Try store.getCart() if it's async
            if (store && typeof store.getCart === 'function') {
                try {
                    const cartData = await Promise.resolve(store.getCart());
                    if (cartData && cartData.lines) {
                        const quantity = cartData.lines.reduce((sum, line) => sum + (line.quantity || 0), 0);
                        if (quantity > 0) {
                            console.log('[CartIcon] ✅ Got quantity from async store.getCart():', quantity);
                            return quantity;
                        }
                    }
                } catch (e) {
                    // Ignore errors
                }
            }
        } catch (error) {
            // Ignore
        }
        
        // Fallback to sync version
        return getCartQuantity(cart, store);
    }

    /**
     * Updates the badge display
     */
    function updateBadge(badge, quantity) {
        if (!badge) return;
        
        const currentDisplay = badge.style.display;
        const currentText = badge.textContent;
        const newText = quantity > 99 ? '99+' : quantity.toString();
        const newDisplay = quantity > 0 ? 'flex' : 'none';
        
        // Only log if something actually changed
        if (currentDisplay !== newDisplay || currentText !== newText) {
            if (quantity > 0) {
                badge.textContent = newText;
                badge.style.display = newDisplay;
                console.log('[CartIcon] ✅ Badge updated:', quantity);
            } else {
                badge.style.display = newDisplay;
                // Don't log when hiding badge (reduces spam)
            }
        }
    }

    /**
     * Sets up event listeners for cart updates
     */
    function setupCartListeners(cart, store, badge) {
        if (eventListenersAttached) {
            console.log('[CartIcon] Event listeners already attached, skipping');
            return;
        }

        const updateCount = () => {
            const quantity = getCartQuantity(cart, store);
            updateBadge(badge, quantity);
            
            // Also try async version if sync returned 0
            if (quantity === 0 && store && typeof store.getCart === 'function') {
                getCartQuantityAsync(cart, store).then(qty => {
                    if (qty > 0) {
                        updateBadge(badge, qty);
                    }
                }).catch(() => {
                    // Ignore errors
                });
            }
        };

        // Listen to cart element events
        if (cart) {
            const cartEvents = [
                'cart:updated',
                'cart:change',
                'cart:line:add',
                'cart:line:remove',
                'cart:line:update',
                'change',
                'update',
                'cart-updated',
                'cart-changed'
            ];

            cartEvents.forEach(eventName => {
                try {
                    cart.addEventListener(eventName, updateCount);
                    console.log(`[CartIcon] ✅ Listening for cart event: ${eventName}`);
                } catch (e) {
                    console.warn(`[CartIcon] Could not listen to cart event ${eventName}:`, e);
                }
            });
        }

        // Listen to store element events (shopify-store is the parent)
        if (store) {
            const storeEvents = [
                'cart:updated',
                'cart:change',
                'store:cart:updated',
                'cart-updated',
                'cart-changed',
                'store:update'
            ];

            storeEvents.forEach(eventName => {
                try {
                    store.addEventListener(eventName, updateCount);
                    console.log(`[CartIcon] ✅ Listening for store event: ${eventName}`);
                } catch (e) {
                    console.warn(`[CartIcon] Could not listen to store event ${eventName}:`, e);
                }
            });
        }

        // Listen to document-level events (Shopify might fire global events)
        const documentEvents = [
            'shopify:cart:updated',
            'shopify:cart:change',
            'cart:updated',
            'cart:change'
        ];

        documentEvents.forEach(eventName => {
            try {
                document.addEventListener(eventName, updateCount);
                console.log(`[CartIcon] ✅ Listening for document event: ${eventName}`);
            } catch (e) {
                console.warn(`[CartIcon] Could not listen to document event ${eventName}:`, e);
            }
        });

        // Watch for attribute changes on cart element
        if (badgeObserver) {
            badgeObserver.disconnect();
        }
        badgeObserver = new MutationObserver((mutations) => {
            updateCount();
        });
        
        if (cart) {
            badgeObserver.observe(cart, {
                attributes: true,
                attributeFilter: ['data-cart', 'data-quantity', 'quantity', 'cart', 'state'],
                childList: true,
                subtree: true
            });
        }

        // Also observe store if available
        if (store) {
            badgeObserver.observe(store, {
                attributes: true,
                attributeFilter: ['cart', 'data-cart', 'data-quantity'],
                childList: true,
                subtree: true
            });
        }

        // Set up polling as fallback (check every 2 seconds)
        if (pollingInterval) {
            clearInterval(pollingInterval);
        }
        pollingInterval = setInterval(() => {
            updateCount();
        }, 2000);
        console.log('[CartIcon] ✅ Polling fallback set up (every 2 seconds)');

        // Initial update
        updateCount();
        eventListenersAttached = true;
        console.log('[CartIcon] ✅ Event listeners, observers, and polling set up');
    }

    /**
     * Finds and initializes the cart badge
     */
    function updateCartBadge() {
        const badge = document.getElementById('cart-count-badge');
        if (!badge) {
            console.warn('[CartIcon] Badge element not found');
            if (retryCount < maxRetries) {
                retryCount++;
                setTimeout(updateCartBadge, 500);
            }
            return;
        }

        // Find the singleton cart (shopify-cart.html)
        let cart = null;
        let store = null;
        
        // Priority 1: Singleton cart
        const cartRoot = document.querySelector('[data-shopify-singleton="true"]');
        if (cartRoot) {
            cart = cartRoot.querySelector('#shopify-cart') || cartRoot.querySelector('shopify-cart');
            store = cartRoot.querySelector('shopify-store') || document.querySelector('shopify-store');
        }
        
        // Priority 2: Fallback to any shopify-cart
        if (!cart) {
            cart = document.querySelector('#shopify-cart') || document.querySelector('shopify-cart');
        }
        if (!store) {
            store = document.querySelector('shopify-store');
        }

        // Store is more important than cart for getting cart data
        if (store || cart) {
            cartElement = cart;
            storeElement = store;

            console.log('[CartIcon] ✅ Cart/Store elements found');
            console.log('[CartIcon] Cart:', cart ? { id: cart.id, tagName: cart.tagName } : 'null');
            console.log('[CartIcon] Store:', store ? { tagName: store.tagName, domain: store.storeDomain } : 'null');
            
            // Set up listeners even if cart isn't fully upgraded
            // We'll use polling as fallback
            setupCartListeners(cart, store, badge);
        } else {
            // Cart/Store not found yet, retry with exponential backoff
            if (retryCount < maxRetries) {
                retryCount++;
                const delay = Math.min(500 * retryCount, 5000); // Max 5 seconds
                console.log(`[CartIcon] Cart/Store not found, retry ${retryCount}/${maxRetries} in ${delay}ms`);
                setTimeout(updateCartBadge, delay);
            } else {
                console.error('[CartIcon] ❌ Cart/Store elements not found after max retries');
                console.error('[CartIcon] Searched for: [data-shopify-singleton="true"] > #shopify-cart, shopify-cart, shopify-store');
                // Still set up polling in case elements appear later
                const badge = document.getElementById('cart-count-badge');
                if (badge) {
                    console.log('[CartIcon] Setting up polling fallback without cart/store');
                    if (pollingInterval) {
                        clearInterval(pollingInterval);
                    }
                    pollingInterval = setInterval(() => {
                        const cart = document.querySelector('#shopify-cart') || document.querySelector('shopify-cart');
                        const store = document.querySelector('shopify-store');
                        if (cart || store) {
                            const quantity = getCartQuantity(cart, store);
                            updateBadge(badge, quantity);
                            
                            // Also try async version if sync returned 0
                            if (quantity === 0 && store && typeof store.getCart === 'function') {
                                getCartQuantityAsync(cart, store).then(qty => {
                                    if (qty > 0) {
                                        updateBadge(badge, qty);
                                    }
                                }).catch(() => {
                                    // Ignore errors
                                });
                            }
                        }
                    }, 2000);
                }
            }
        }
    }

    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            console.log('[CartIcon] DOM ready, initializing badge...');
            setTimeout(updateCartBadge, 100);
        });
    } else {
        // DOM is already ready, but wait a bit for Shopify components to load
        console.log('[CartIcon] DOM already ready, initializing badge...');
        setTimeout(updateCartBadge, 100);
    }

    // Also listen for shopify-html-ready event (fired when HTML is injected)
    window.addEventListener('shopify-html-ready', () => {
        console.log('[CartIcon] shopify-html-ready event received, retrying...');
        retryCount = 0; // Reset retry count
        setTimeout(updateCartBadge, 200);
    }, { once: false });

    // Expose manual update function for debugging/testing
    window.updateCartBadge = function() {
        console.log('[CartIcon] Manual update triggered');
        retryCount = 0;
        const badge = document.getElementById('cart-count-badge');
        if (!badge) {
            console.warn('[CartIcon] Badge not found for manual update');
            return;
        }
        const cart = document.querySelector('#shopify-cart') || document.querySelector('shopify-cart');
        const store = document.querySelector('shopify-store');
        const quantity = getCartQuantity(cart, store);
        updateBadge(badge, quantity);
        
        // Also try async version if sync returned 0
        if (quantity === 0 && store && typeof store.getCart === 'function') {
            getCartQuantityAsync(cart, store).then(qty => {
                if (qty > 0) {
                    updateBadge(badge, qty);
                    console.log('[CartIcon] Manual update (async) complete, quantity:', qty);
                }
            }).catch(() => {
                // Ignore errors
            });
        }
        console.log('[CartIcon] Manual update complete, quantity:', quantity);
    };

    // Hook into add-to-cart action to update badge immediately
    document.addEventListener('click', (e) => {
        const button = e.target.closest('[data-custom-shopify-action="add-to-cart"]');
        if (button) {
            console.log('[CartIcon] Add-to-cart button clicked, will update badge in 500ms');
            // Wait a bit for cart to update, then refresh badge
            setTimeout(() => {
                if (window.updateCartBadge) {
                    window.updateCartBadge();
                }
            }, 500);
        }
    }, true); // Use capture phase to catch early

    console.log('[CartIcon] Script initialized. Use window.updateCartBadge() to manually update.');
})();

