import { HtmlHandler } from '../HtmlInjection/HtmlHandler.mjs';
import { ShopifyConfig } from './shopify-config.mjs';

/**
 * Specialized HTML handler for Shopify components.
 * Extends HtmlHandler with Shopify-specific event handling and initialization.
 * 
 * Supports multiple HTML assets and fires 'shopifyHtmlReady' event only after ALL
 * HTML files are injected into the DOM.
 */
export class ShopifyHtmlHandler extends HtmlHandler {

    static scriptName = 'shopifyHtmlHandler';

    // Global flag to ensure we only set up one document-level event listener
    static shopifyEventsBound = false;

    /**
     * Exposes store-wide config on window for inline HTML scripts (if any run).
     */
    static exposeConfigOnWindow() {
        if (typeof window === 'undefined') return;
        if (window.__SHOPIFY_CONFIG__) return;
        window.__SHOPIFY_CONFIG__ = { ...ShopifyConfig };
    }

    /**
     * Replaces placeholder tokens in HTML assets with values from shopify-config.mjs.
     * @param {string} htmlContent
     * @returns {string}
     */
    static applyConfigToHtml(htmlContent) {
        if (!htmlContent) return htmlContent;
        const c = ShopifyConfig;
        return htmlContent
            .replace(/YOUR_SHOPIFY_STORE_DOMAIN/g, c.storeDomain)
            .replace(/YOUR_SHOPIFY_WEB_COMPONENTS_CDN/g, c.webComponentsCdnUrl)
            .replace(/YOUR_DEFAULT_COUNTRY/g, c.defaultCountryCode)
            .replace(/YOUR_DEFAULT_LANGUAGE/g, c.defaultLanguageCode)
            .replace(/YOUR_FALLBACK_PRODUCT_HANDLE/g, c.fallbackProductHandle)
            .replace(/YOUR_LOCALSTORAGE_COUNTRY_KEY/g, c.localStorageCountryKey);
    }

    /**
     * Builds a shopify-store element string for country-rebuild paths.
     * @param {string} countryCode
     * @returns {string}
     */
    static buildStoreHtml(countryCode) {
        const c = ShopifyConfig;
        return '<shopify-store id="shopify-store-element" store-domain="' + c.storeDomain + '" country="' + countryCode + '" language="' + c.defaultLanguageCode + '"></shopify-store>';
    }

    /**
     * Builds country selector option HTML from config.
     * @param {string} selectedCountryCode
     * @returns {string}
     */
    static buildCountryOptionsHtml(selectedCountryCode) {
        return ShopifyConfig.supportedCountries.map(({ code, label }) =>
            '<option value="' + code + '"' + (selectedCountryCode === code ? ' selected' : '') + '>' + label + '</option>'
        ).join('');
    }

    /**
     * Ensures the Web Components CDN script is loaded once.
     */
    static ensureWebComponentsScript() {
        const cdnUrl = ShopifyConfig.webComponentsCdnUrl;
        if (!document.querySelector('script[src="' + cdnUrl + '"]') &&
            !document.querySelector('script[data-shopify-web-components]')) {
            const script = document.createElement('script');
            script.type = 'module';
            script.src = cdnUrl;
            script.setAttribute('data-shopify-web-components', 'true');
            document.head.appendChild(script);
        }
    }

    /**
     * Checks if an HTML asset is a Shopify template
     * @param {pc.Asset} asset - The HTML asset to check
     * @param {string} htmlContent - The HTML content
     * @returns {boolean} True if this is Shopify HTML
     */
    isShopifyHtml(asset, htmlContent) {
        if (!asset) return false;
        
        const assetName = (asset.name || '').toLowerCase();
        const isShopifyName = assetName.includes('shopify') || 
                             assetName.includes('popup-menu-shopify') ||
                             assetName.includes('cart-icon') ||
                             assetName.includes('shopify-global');
        
        const isShopifyContent = htmlContent.includes('<shopify-context') ||
                                htmlContent.includes('<shopify-cart') ||
                                htmlContent.includes('<shopify-store') ||
                                htmlContent.includes('<shopify-money');
        
        return isShopifyName || isShopifyContent;
    }

    /**
     * Gets the product handle from the entity's ShopifyProductHandler script if available.
     * @returns {string|null} The product handle or null if not found
     */
    getProductHandleFromEntity() {
        // Check if this entity has ShopifyProductHandler
        if (this.entity && this.entity.script && this.entity.script.shopifyProductHandler) {
            const handler = this.entity.script.shopifyProductHandler;
            if (handler.productHandle && handler.productHandle.trim() !== '') {
                return handler.productHandle.trim();
            }
        }
        
        // Check parent entity
        if (this.entity && this.entity.parent && this.entity.parent.script) {
            if (this.entity.parent.script.shopifyProductHandler) {
                const handler = this.entity.parent.script.shopifyProductHandler;
                if (handler.productHandle && handler.productHandle.trim() !== '') {
                    return handler.productHandle.trim();
                }
            }
        }
        
        // Check children entities
        if (this.entity && this.entity.children) {
            for (const child of this.entity.children) {
                if (child.script && child.script.shopifyProductHandler) {
                    const handler = child.script.shopifyProductHandler;
                    if (handler.productHandle && handler.productHandle.trim() !== '') {
                        return handler.productHandle.trim();
                    }
                }
            }
        }
        
        return null;
    }

    /**
     * Replaces placeholder-product handles in HTML content with the actual product handle.
     * Preserves placeholder-product for shopify-global.html (preload context needs it).
     * 
     * @param {string} htmlContent - The HTML content
     * @param {string} assetName - The name of the HTML asset
     * @param {string|null} productHandle - The product handle to use (optional, will try to get from entity)
     * @returns {string} HTML with handles replaced
     */
    replacePlaceholderHandles(htmlContent, assetName, productHandle = null) {
        // Don't replace for shopify-global.html - it uses placeholder-product intentionally for the preload context
        if (assetName && assetName.toLowerCase().includes('shopify-global')) {
            return htmlContent;
        }
        
        // Get product handle if not provided
        if (!productHandle) {
            productHandle = this.getProductHandleFromEntity();
        }
        
        // If no handle found, keep placeholder (but log a warning)
        if (!productHandle || productHandle.trim() === '' || productHandle === 'placeholder-product') {
            if (htmlContent.includes('placeholder-product') && htmlContent.includes('<shopify-context')) {
                console.warn(`[ShopifyHtmlHandler] No product handle found for ${assetName}. Using placeholder-product. Make sure the entity has ShopifyProductHandler with productHandle set.`);
            }
            return htmlContent;
        }
        
        // Replace placeholder-product with actual handle
        const replacedHtml = htmlContent.replace(/handle="placeholder-product"/gi, `handle="${productHandle}"`);
        const replacedHtml2 = replacedHtml.replace(/handle='placeholder-product'/gi, `handle='${productHandle}'`);
        
        if (replacedHtml2 !== htmlContent) {
            console.log(`[ShopifyHtmlHandler] Replaced placeholder-product with "${productHandle}" in ${assetName}`);
        }
        
        return replacedHtml2;
    }

    /**
     * Override initialize to handle multiple HTML assets
     */
    initialize() {
        ShopifyHtmlHandler.exposeConfigOnWindow();

        // Get unique ID for this instance
        this.uniqueId = this.entity.getGuid();
        
        // Collect HTML assets
        const htmlAssets = this.getHtmlAssets();
        
        if (htmlAssets.length === 0) {
            console.warn('[ShopifyHtmlHandler] No HTML assets configured');
            return;
        }

        // Prevent duplicate Shopify cart injection (singleton guard)
        const hasCartFile = htmlAssets.some(asset => 
            asset && asset.name && asset.name.toLowerCase().includes('shopify-cart.html')
        );

        if (hasCartFile) {
            const existingCartRoot = document.querySelector('[data-shopify-singleton="true"]');
            if (existingCartRoot) {
                console.warn('[ShopifyHtmlHandler] shopify-cart.html already injected — skipping duplicate');
                // Still process other HTML assets, just skip the cart one
                const filteredAssets = htmlAssets.filter(asset => 
                    !asset || !asset.name || !asset.name.toLowerCase().includes('shopify-cart.html')
                );
                if (filteredAssets.length === 0) {
                    console.warn('[ShopifyHtmlHandler] No HTML assets to inject after filtering cart');
                    return;
                }
                // Continue with filtered assets
                htmlAssets.length = 0;
                htmlAssets.push(...filteredAssets);
            }
        }

        // Create main container div
        this.div = document.createElement('div');
        this.div.setAttribute('data-shopify-handler', this.uniqueId);
        
        // Track injection status
        this.htmlInjectionStatus = new Map();
        htmlAssets.forEach(asset => {
            if (asset && asset.name) {
                this.htmlInjectionStatus.set(asset.name, false);
            }
        });

        // Get product handle once (if available)
        const productHandle = this.getProductHandleFromEntity();
        if (productHandle) {
            console.log(`[ShopifyHtmlHandler] Entity has product handle: "${productHandle}"`);
        }

        // Store popup root element for product handler (TASK 1)
        this.popupRootEl = null;

        // Inject all HTML assets
        htmlAssets.forEach((htmlAsset, index) => {
            if (!htmlAsset || !htmlAsset.resource) {
                console.warn(`[ShopifyHtmlHandler] HTML asset at index ${index} is missing or has no resource`);
                return;
            }

            let htmlContent = htmlAsset.resource || '';

            htmlContent = ShopifyHtmlHandler.applyConfigToHtml(htmlContent);
            
            // Check if this is Shopify HTML - if so, skip ID uniquification
            const isShopify = this.isShopifyHtml(htmlAsset, htmlContent);
            
            // Replace placeholder-product handles BEFORE any other processing
            htmlContent = this.replacePlaceholderHandles(htmlContent, htmlAsset.name, productHandle);
            
            // Log the HTML before injection (for debugging)
            if (isShopify && htmlContent.includes('shopify-context')) {
                const handleMatch = htmlContent.match(/handle=["']([^"']+)["']/i);
                const handle = handleMatch ? handleMatch[1] : 'not found';
                console.log(`[ShopifyHtmlHandler] BEFORE INJECT - ${htmlAsset.name}`, {
                    handle: handle,
                    hasPlaceholder: htmlContent.includes('placeholder-product'),
                    htmlPreview: htmlContent.substring(0, 200)
                });
            }
            
            // Extract script tags from HTML (they won't execute if added via innerHTML)
            const scriptTagMatch = htmlContent.match(/<script[^>]*src=["']([^"']+)["'][^>]*><\/script>/i);
            let scriptToInject = null;
            let htmlWithoutScript = htmlContent;
            
            if (scriptTagMatch) {
                // Extract the script tag
                scriptToInject = scriptTagMatch[0];
                // Remove script tag from HTML content
                htmlWithoutScript = htmlContent.replace(/<script[^>]*src=["'][^"']+["'][^>]*><\/script>/i, '');
                console.log(`[ShopifyHtmlHandler] Found script tag in ${htmlAsset.name}, will inject separately`);
            }
            
            // TASK 1 & 6: Check if this is popup-menu-shopify.html
            const isPopupMenuShopify = htmlAsset.name && htmlAsset.name.toLowerCase().includes('popup-menu-shopify');
            
            // TASK 6: Uniquify IDs inside popup-menu-shopify.html per entity (Option A)
            let finalHtml = htmlWithoutScript;
            if (isPopupMenuShopify) {
                // Uniquify all IDs in the popup HTML
                finalHtml = this.makeIdsUniqueForPopup(htmlWithoutScript, this.uniqueId);
                console.log(`[ShopifyHtmlHandler] Uniquified IDs in popup-menu-shopify.html for entity ${this.uniqueId}`);
            } else if (!isShopify) {
                // For non-Shopify HTML, use standard uniquification
                finalHtml = this.makeIdsUnique(htmlWithoutScript, this.uniqueId);
            } else {
                console.log(`[ShopifyHtmlHandler] Skipping ID uniquification for Shopify HTML: ${htmlAsset.name}`);
            }
            
            // Create a div for this HTML asset
            const assetDiv = document.createElement('div');
            assetDiv.setAttribute('data-shopify-asset', htmlAsset.name);
            
            // For popup-menu-shopify.html, wrap in unique root container
            if (isPopupMenuShopify) {
                const popupRoot = document.createElement('div');
                popupRoot.className = 'shopify-popup-root';
                popupRoot.setAttribute('data-shopify-entity-id', this.uniqueId);
                
                // Store for ProductHandler to access
                this.popupRootEl = popupRoot;
                
                // Create asset div inside popup root
                assetDiv.setAttribute('data-shopify-asset', htmlAsset.name);
                popupRoot.appendChild(assetDiv);
                
                // We'll append popupRoot instead of assetDiv later
            }
            
            // Inject script tag first (if present) - check if it already exists to avoid duplicates
            if (scriptToInject) {
                const scriptSrcMatch = scriptToInject.match(/src=["']([^"']+)["']/i);
                const scriptSrc = scriptSrcMatch ? scriptSrcMatch[1] : null;
                
                if (scriptSrc) {
                    // Check if script already exists
                    const existingScript = document.querySelector(`script[src="${scriptSrc}"]`) ||
                                         document.querySelector('script[data-shopify-web-components]');
                    
                    if (!existingScript) {
                        // Inject script into head
                        const scriptElement = document.createElement('script');
                        scriptElement.type = "module";
                        scriptElement.src = scriptSrc;
                        scriptElement.setAttribute("data-shopify-web-components", "true");
                        document.head.appendChild(scriptElement);
                        console.log(`[ShopifyHtmlHandler] Injected Shopify script from ${htmlAsset.name}`);
                    } else {
                        console.log(`[ShopifyHtmlHandler] Script already exists, skipping duplicate injection`);
                    }
                }
            }
            
            assetDiv.innerHTML = finalHtml;
            
            // Check for duplicate store/cart elements and remove them if already exist globally
            if (isShopify) {
                // Remove duplicate shopify-store if one already exists
                const existingStore = document.querySelector('shopify-store');
                const newStore = assetDiv.querySelector('shopify-store');
                if (existingStore && newStore && existingStore !== newStore) {
                    console.log(`[ShopifyHtmlHandler] Duplicate shopify-store detected, removing from ${htmlAsset.name}`);
                    newStore.remove();
                }
                
                // Remove duplicate shopify-cart if one already exists (singleton check)
                const existingCartRoot = document.querySelector('[data-shopify-singleton="true"]');
                const existingCart = existingCartRoot ? 
                    (existingCartRoot.querySelector('#shopify-cart') || existingCartRoot.querySelector('shopify-cart')) :
                    (document.querySelector('#shopify-cart') || document.querySelector('shopify-cart'));
                const newCart = assetDiv.querySelector('#shopify-cart') || assetDiv.querySelector('shopify-cart');
                if (existingCart && newCart && existingCart !== newCart) {
                    console.log(`[ShopifyHtmlHandler] Duplicate shopify-cart detected, removing from ${htmlAsset.name}`);
                    newCart.remove();
                }
            }
            
            // Log the handle after DOM insertion (for verification)
            if (isShopify) {
                setTimeout(() => {
                    const context = assetDiv.querySelector('shopify-context');
                    const injectedHandle = context ? context.getAttribute('handle') : null;
                    const store = assetDiv.querySelector('shopify-store') || document.querySelector('shopify-store');
                    const cart = assetDiv.querySelector('shopify-cart') || document.querySelector('shopify-cart');
                    
                    console.log(`[ShopifyHtmlHandler] AFTER INJECT - ${htmlAsset.name}`, {
                        handle: injectedHandle,
                        contextExists: !!context,
                        storeExists: !!store,
                        cartExists: !!cart
                    });
                }, 0);
            }
            
            // Append either popupRoot (with assetDiv inside) or just assetDiv
            if (isPopupMenuShopify && this.popupRootEl) {
                this.div.appendChild(this.popupRootEl);
            } else {
                this.div.appendChild(assetDiv);
            }
        });

        this.waitForCanvasUI();
    }

    /**
     * Override bindEvents to add Shopify-specific functionality
     */
    bindEvents() {
        // Get HTML assets
        const htmlAssets = this.getHtmlAssets();
        
        htmlAssets.forEach(htmlAsset => {
            if (!htmlAsset) return;
            
            const htmlContent = htmlAsset.resource || '';
            const isShopify = this.isShopifyHtml(htmlAsset, htmlContent);
            
            // Check if this is popup-menu-shopify.html (which gets uniquified)
            const isPopupMenuShopify = htmlAsset.name && htmlAsset.name.toLowerCase().includes('popup-menu-shopify');
            
            // For Shopify HTML, handle close buttons
            if (isShopify) {
                // For popup-menu-shopify, IDs are uniquified, so we need to use the uniquified ID
                if (isPopupMenuShopify) {
                    const modalMatch = htmlContent.match(/id="([^"]*popup-menu[^"]*)"/i) ||
                                      htmlContent.match(/id="([^"]*modal[^"]*)"/i);
                    if (modalMatch) {
                        const baseModalId = modalMatch[1];
                        const uniquifiedModalId = `${baseModalId}-${this.uniqueId}`;
                        const modalElement = document.getElementById(uniquifiedModalId);
                        if (modalElement) {
                            const span = modalElement.getElementsByClassName('close-button')[0];
                            if (span) {
                                span.onclick = function() {
                                    modalElement.style.display = "none";
                                }
                            }
                        }
                    }
                } else {
                    // For other Shopify HTML, use original IDs (not uniquified)
                    const modalMatch = htmlContent.match(/id="([^"]*popup-menu[^"]*)"/i) ||
                                      htmlContent.match(/id="([^"]*modal[^"]*)"/i);
                    if (modalMatch) {
                        const modalId = modalMatch[1];
                        const modalElement = document.getElementById(modalId);
                        if (modalElement) {
                            const span = modalElement.getElementsByClassName('close-button')[0];
                            if (span) {
                                span.onclick = function() {
                                    modalElement.style.display = "none";
                                }
                            }
                        }
                    }
                }
            } else {
                // For non-Shopify HTML, use the original unique ID logic
                const baseId = this.removeHtmlExtensionRegex(htmlAsset.name);
                const uniqueId = this.getUniqueIdFor(baseId);
                const modal = document.getElementById(uniqueId);
                
                if (modal) {
                    const span = modal.getElementsByClassName('close-button')[0];
                    if (span) {
                        span.onclick = function() {
                            modal.style.display = "none";
                        }
                    }
                }
            }
        });
        
        // Shopify-specific event handling on the main container
        this.removeShopifyActionAttributes(this.div);
        this.setupShopifyButtonObserver(this.div);
        this.bindShopifyEvents(this.div);
    }

    /**
     * Makes all IDs in the HTML unique by appending a unique identifier.
     * Used for non-Shopify HTML that needs uniquification.
     * 
     * @param {string} html - The HTML content
     * @param {string} uniqueId - Unique identifier to append
     * @returns {string} HTML with unique IDs
     */
    makeIdsUnique(html, uniqueId) {
        // Replace id="..." with id="...-{uniqueId}"
        return html.replace(/id="([^"]+)"/g, (match, id) => {
            // Don't uniquify if already uniquified
            if (id.endsWith(`-${uniqueId}`)) {
                return match;
            }
            return `id="${id}-${uniqueId}"`;
        });
    }

    /**
     * Gets the unique ID for this HTML handler instance.
     * 
     * @returns {string} The unique ID
     */
    getUniqueId() {
        return this.uniqueId;
    }

    /**
     * Gets the unique ID for a given base ID.
     * 
     * @param {string} baseId - The base ID (without unique suffix)
     * @returns {string} The uniquified ID
     */
    getUniqueIdFor(baseId) {
        return `${baseId}-${this.uniqueId}`;
    }

    /**
     * Uniquifies IDs specifically for popup-menu-shopify.html
     * Adds entity GUID suffix to all IDs
     */
    makeIdsUniqueForPopup(html, uniqueId) {
        // Replace all id="..." with id="...-{uniqueId}"
        return html.replace(/id="([^"]+)"/g, (match, id) => {
            // Don't uniquify if already uniquified
            if (id.endsWith(`-${uniqueId}`)) {
                return match;
            }
            return `id="${id}-${uniqueId}"`;
        });
    }

    /**
     * Returns the popup root element for this entity instance
     * Used by ProductHandler to scope its queries
     * 
     * @returns {HTMLElement|null} The popup root element or null if not found
     */
    getPopupRootEl() {
        return this.popupRootEl;
    }

    /**
     * Returns a Promise that resolves when this entity's popup is injected
     * Used by ProductHandler for scoped binding (TASK 3)
     * 
     * @returns {Promise<HTMLElement>} Promise that resolves with popup root element
     */
    injectPopupPromise() {
        if (this.popupRootEl && this.popupRootEl.isConnected) {
            return Promise.resolve(this.popupRootEl);
        }
        
        return new Promise((resolve) => {
            const checkInterval = setInterval(() => {
                if (this.popupRootEl && this.popupRootEl.isConnected) {
                    clearInterval(checkInterval);
                    resolve(this.popupRootEl);
                }
            }, 50);
            
            // Timeout after 5 seconds
            setTimeout(() => {
                clearInterval(checkInterval);
                if (this.popupRootEl) {
                    resolve(this.popupRootEl);
                } else {
                    console.warn('[ShopifyHtmlHandler] Popup root not found after timeout');
                    resolve(null);
                }
            }, 5000);
        });
    }

    /**
     * Override waitForCanvasUI to fire event when ALL HTML is injected
     */
    waitForCanvasUI(retryDelay = 200) {
        var worldRoot = document.getElementById('canvas-wrapper');

        if (worldRoot == null) {
            // Add retry limit to prevent infinite loops
            if (!this.canvasRetryCount) {
                this.canvasRetryCount = 0;
            }
            this.canvasRetryCount++;
            
            // Log warning after several retries
            if (this.canvasRetryCount === 10) {
                console.warn('[ShopifyHtmlHandler] canvas-wrapper not found after 10 retries. HTML will not be injected.');
                console.warn('[ShopifyHtmlHandler] Available elements:', {
                    body: !!document.body,
                    canvasWrapper: !!document.getElementById('canvas-wrapper'),
                    allIds: Array.from(document.querySelectorAll('[id]')).map(el => el.id).slice(0, 10)
                });
            }
            
            // Stop retrying after 50 attempts (10 seconds)
            if (this.canvasRetryCount < 50) {
                setTimeout(() => this.waitForCanvasUI(retryDelay), retryDelay);
            } else {
                console.error('[ShopifyHtmlHandler] Failed to inject HTML: canvas-wrapper element not found after 50 retries');
                // Try to inject into body as fallback
                if (document.body) {
                    console.warn('[ShopifyHtmlHandler] Attempting fallback injection into document.body');
                    document.body.appendChild(this.div);
                    console.log("HTML INJECTED (fallback to body)", performance.now());
                    this.handleInjectionComplete();
                }
            }
            return;
        }
        else {
            worldRoot.appendChild(this.div);
            console.log("HTML INJECTED", performance.now());
            console.log('[ShopifyHtmlHandler] Injected div with', this.div.children.length, 'child elements');
            console.log('[ShopifyHtmlHandler] Div content preview:', this.div.innerHTML.substring(0, 200));
            
            // Verify the popup-menu-shopify element exists
            const popupMenu = this.div.querySelector('#popup-menu-shopify');
            if (popupMenu) {
                console.log('[ShopifyHtmlHandler] ✅ popup-menu-shopify element found in injected HTML');
            } else {
                console.warn('[ShopifyHtmlHandler] ⚠️ popup-menu-shopify element NOT found in injected HTML');
                console.warn('[ShopifyHtmlHandler] Available IDs in div:', 
                    Array.from(this.div.querySelectorAll('[id]')).map(el => el.id)
                );
            }
            
            this.handleInjectionComplete();
        }
    }

    /**
     * Handles completion of HTML injection (extracted for reuse)
     */
    handleInjectionComplete() {
        // Get HTML assets
        const htmlAssets = this.getHtmlAssets();
        
        // Mark all HTML assets as injected
        htmlAssets.forEach(asset => {
            if (asset && asset.name) {
                this.htmlInjectionStatus.set(asset.name, true);
            }
        });
        
        // Check if all HTML assets are injected
        const allInjected = Array.from(this.htmlInjectionStatus.values()).every(injected => injected === true);
        
        if (allInjected) {
            // Fire event to notify that all Shopify HTML is ready
            const htmlNames = htmlAssets.map(a => a?.name).filter(Boolean);
            this.app.fire('shopifyHtmlReady', { 
                htmlNames, 
                uniqueId: this.uniqueId,
                allHtmlAssets: htmlAssets.length
            });
            console.log("[ShopifyHtmlHandler] Fired shopifyHtmlReady event for all HTML assets:", htmlNames);
            
            // Ensure Shopify custom elements are upgraded for newly injected HTML
            if (window.Shopify?.webComponents?.loadComponents) {
                try {
                    window.Shopify.webComponents.loadComponents();
                    console.log("[ShopifyHtmlHandler] Called loadComponents() to upgrade custom elements");
                } catch (error) {
                    console.warn("[ShopifyHtmlHandler] Error calling loadComponents():", error);
                }
            }
            
            // TASK 3: REMOVED global shopify-html-ready event
            // ProductHandler now uses injectPopupPromise() for scoped binding
            // Keep event for backward compatibility but log warning
            console.log("[ShopifyHtmlHandler] HTML injection complete. Use injectPopupPromise() for scoped access.");
            
            // Event-driven approach: Wait for components to upgrade and hydrate
            this.waitForComponentHydration();
            
            // Cart verification (runs independently, doesn't depend on product contexts)
            this.verifyCartSingleton();
        }
        
        this.bindEvents();
    }

    /**
     * Removes data-shopify-action attributes to prevent Shopify from adding inline handlers.
     * Stores the action value in a custom attribute for our event handler.
     * 
     * @param {HTMLElement} container - The container element to search within
     */
    removeShopifyActionAttributes(container) {
        if (!container) return;

        const buttons = container.querySelectorAll('[data-shopify-action]');
        buttons.forEach(button => {
            const action = button.getAttribute('data-shopify-action');
            if (action) {
                button.removeAttribute('data-shopify-action');
                button.setAttribute('data-custom-shopify-action', action);
            }
        });
    }

    /**
     * Sets up a MutationObserver to watch for buttons rendered by Shopify templates
     * and remove data-shopify-action attributes as they're added to the DOM.
     * 
     * @param {HTMLElement} container - The container element to observe
     */
    setupShopifyButtonObserver(container) {
        if (!container) return;

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) {
                        if (node.hasAttribute && node.hasAttribute('data-shopify-action')) {
                            const action = node.getAttribute('data-shopify-action');
                            if (action) {
                                node.removeAttribute('data-shopify-action');
                                node.setAttribute('data-custom-shopify-action', action);
                            }
                        }
                        if (node.querySelectorAll) {
                            const buttons = node.querySelectorAll('[data-shopify-action]');
                            buttons.forEach(button => {
                                const action = button.getAttribute('data-shopify-action');
                                if (action) {
                                    button.removeAttribute('data-shopify-action');
                                    button.setAttribute('data-custom-shopify-action', action);
                                }
                            });
                        }
                    }
                });
            });
        });

        observer.observe(container, {
            childList: true,
            subtree: true
        });

        this.shopifyButtonObserver = observer;
    }

    /**
     * Extracts the uniqueId from a button's DOM context by looking for elements with unique ID patterns.
     * 
     * @param {HTMLElement} button - The button element
     * @returns {string|null} The uniqueId if found, null otherwise
     */
    static extractUniqueIdFromContext(button) {
        let element = button;
        let depth = 0;
        const maxDepth = 20;
        
        while (element && depth < maxDepth) {
            if (element.id && element.id.includes('-')) {
                const lastHyphenIndex = element.id.lastIndexOf('-');
                if (lastHyphenIndex > 0) {
                    const potentialUniqueId = element.id.substring(lastHyphenIndex + 1);
                    if (potentialUniqueId && /^[a-f0-9]{8,}$/i.test(potentialUniqueId)) {
                        return potentialUniqueId;
                    }
                }
            }
            element = element.parentElement;
            depth++;
        }
        return null;
    }

    /**
     * Handles Shopify button click actions.
     * 
     * @param {Event} event - The click event
     * @param {HTMLElement} button - The button that was clicked
     * @param {string|null} uniqueId - Optional uniqueId for this handler instance
     */
    static handleShopifyClick(event, button, uniqueId = null) {
        const action = button.getAttribute('data-custom-shopify-action');
        if (!action) return;

        if (!uniqueId) {
            uniqueId = ShopifyHtmlHandler.extractUniqueIdFromContext(button);
        }

        if (action === 'view-cart') {
            console.log("🧪 [ShopifyHtmlHandler] view-cart action triggered from button:", button);
            console.log("🧪 [ShopifyHtmlHandler] Inferred uniqueId:", uniqueId);
        }

        switch (action) {
            case 'view-product':
            case 'open-product-modal': {
                // Find the product context (single source of truth)
                let productContext = button.closest('shopify-context[type="product"]');
                
                // Fallback: search parent elements if closest didn't find it
                if (!productContext) {
                    let parent = button.parentElement;
                    while (parent && !productContext) {
                        if (parent.tagName === 'SHOPIFY-CONTEXT' && parent.getAttribute('type') === 'product') {
                            productContext = parent;
                        } else {
                            parent = parent.parentElement;
                        }
                    }
                }
                
                if (!productContext) {
                    console.warn('[ShopifyHtmlHandler] Product context not found');
                    return;
                }
                
                const handle = productContext.getAttribute('handle');
                console.log('[ShopifyHtmlHandler] View product clicked, handle:', handle);
                
                // Verify we only have one product context
                const allProductContexts = document.querySelectorAll('shopify-context[type="product"]');
                if (allProductContexts.length > 1) {
                    console.warn('[ShopifyHtmlHandler] ⚠️ Multiple product contexts detected:', allProductContexts.length);
                }
                
                // Find modal using class selector (classes aren't uniquified) or by ID pattern
                // Try multiple strategies since modal might be in shadowRoot or rendered template
                let modal = null;
                
                // Strategy 1: Search by class within the context (works if rendered in light DOM)
                modal = productContext.querySelector('.product-modal') ||
                        productContext.querySelector('dialog.product-modal');
                
                // Strategy 2: If context has shadowRoot, check there too
                if (!modal && productContext.shadowRoot) {
                    modal = productContext.shadowRoot.querySelector('.product-modal') ||
                            productContext.shadowRoot.querySelector('dialog.product-modal');
                }
                
                // Strategy 3: Find by uniquified ID pattern if we have uniqueId
                if (!modal && uniqueId) {
                    const uniquifiedId = `product-modal-${uniqueId}`;
                    modal = document.getElementById(uniquifiedId);
                    if (!modal && productContext.querySelector) {
                        modal = productContext.querySelector(`#${uniquifiedId}`);
                    }
                }
                
                // Strategy 4: Find via popup menu (modal is rendered as sibling/nearby in DOM)
                if (!modal) {
                    const popupMenu = button.closest('.popup-menu');
                    if (popupMenu) {
                        modal = popupMenu.querySelector('.product-modal') ||
                                popupMenu.querySelector('dialog.product-modal');
                    }
                }
                
                // Strategy 5: Global search by class as last resort
                if (!modal) {
                    const allModals = document.querySelectorAll('dialog.product-modal');
                    if (allModals.length > 0) {
                        // Get the context's position in DOM to find closest
                        const contextRect = productContext.getBoundingClientRect();
                        let closestModal = allModals[0];
                        let closestDistance = Infinity;
                        
                        allModals.forEach(m => {
                            const mRect = m.getBoundingClientRect();
                            const distance = Math.abs(mRect.top - contextRect.top) + Math.abs(mRect.left - contextRect.left);
                            if (distance < closestDistance) {
                                closestDistance = distance;
                                closestModal = m;
                            }
                        });
                        modal = closestModal;
                    }
                }
                
                if (modal) {
                    // Apply modal styles
                    modal.style.maxWidth = '54rem';
                    modal.style.width = '90vw';
                    modal.style.maxHeight = '90vh';
                    modal.style.height = 'auto';
                    modal.style.margin = 'auto';
                    
                    // Open the modal
                    modal.showModal();
                    console.log('[ShopifyHtmlHandler] Modal opened successfully');
                } else {
                    console.warn('[ShopifyHtmlHandler] Product modal not found. Tried: context.querySelector, shadowRoot, uniquified ID, popup menu, global search.');
                    console.warn('[ShopifyHtmlHandler] Context:', productContext, 'hasShadowRoot:', !!productContext.shadowRoot, 'uniqueId:', uniqueId);
                }
                break;
            }

            case 'close-modal': {
                const modal = button.closest('.product-modal');
                if (modal) {
                    modal.close();
                } else {
                    const modalById = document.getElementById(`product-modal-${uniqueId}`);
                    if (modalById) {
                        modalById.close();
                    }
                }
                break;
            }

            case 'add-to-cart': {
                // Find the product context that contains this button
                let productContext = button.closest('shopify-context[type="product"]');
                
                // Fallback: search parent elements if closest didn't find it
                if (!productContext) {
                    let parent = button.parentElement;
                    while (parent && !productContext) {
                        if (parent.tagName === 'SHOPIFY-CONTEXT' && parent.getAttribute('type') === 'product') {
                            productContext = parent;
                        } else {
                            parent = parent.parentElement;
                        }
                    }
                }
                
                if (!productContext) {
                    console.warn('[ShopifyHtmlHandler] Product context not found for add-to-cart');
                    return;
                }
                
                // Use singleton cart (shopify-cart.html)
                let cart = null;
                
                // Priority 1: Singleton cart
                const cartRoot = document.querySelector('[data-shopify-singleton="true"]');
                if (cartRoot) {
                    cart = cartRoot.querySelector('#shopify-cart') || cartRoot.querySelector('shopify-cart');
                }
                
                // Priority 2: Fallback to any shopify-cart
                if (!cart) {
                    cart = document.querySelector('#shopify-cart') || document.querySelector('shopify-cart');
                }
                
                if (!cart) {
                    console.warn('[ShopifyHtmlHandler] Cart not found for add-to-cart action');
                    return;
                }
                
                if (!cart.addLine) {
                    console.warn('[ShopifyHtmlHandler] Cart element found but addLine method not available');
                    return;
                }
                
                // Note: We don't need to block if productContext.product isn't accessible because:
                // 1. The modal is already showing product data (so it's loaded)
                // 2. cart.addLine(event) will extract variant info from the event's DOM context
                // 3. The button is inside the product context template, so Shopify can find it via event.target
                // Log for debugging but don't block
                if (!productContext.product) {
                    console.log('[ShopifyHtmlHandler] Product context.product not accessible, but proceeding (cart.addLine will extract from event context)');
                } else {
                    console.log('[ShopifyHtmlHandler] Product context has product data available');
                }
                
                // Use setTimeout to run asynchronously and prevent UI blocking
                setTimeout(() => {
                    try {
                        console.log('[ShopifyHtmlHandler] Attempting to add item to cart...');
                        
                        // Shopify's addLine method extracts variant from the event's context
                        // Since the button is within the product context, the event should carry that info
                        const result = cart.addLine(event);
                        
                        // Handle result - addLine might return a promise
                        if (result && typeof result.then === 'function') {
                            // If addLine returns a promise
                            result.then(() => {
                                console.log('[ShopifyHtmlHandler] Item added to cart successfully (async)');
                                // Show cart modal after a brief delay using requestAnimationFrame
                                requestAnimationFrame(() => {
                                    setTimeout(() => {
                                        try {
                                            console.log('[ShopifyHtmlHandler] Attempting to show cart modal (async)...');
                                            
                                            // Show the cart root container first (same as view-cart handler)
                                            const cartRoot = document.getElementById('shopify-cart-root');
                                            if (cartRoot) {
                                                cartRoot.style.display = 'block';
                                                console.log('[ShopifyHtmlHandler] ✅ Cart root container shown (async)');
                                            }
                                            
                                            if (cart.showModal) {
                                                cart.showModal();
                                                console.log('[ShopifyHtmlHandler] Cart modal shown (async)');
                                            } else {
                                                console.warn('[ShopifyHtmlHandler] No showModal method available on cart (async)');
                                            }
                                            
                                            // Ensure the dialog in shadowRoot is visible and styled (same as view-cart handler)
                                            if (cart.shadowRoot) {
                                                setTimeout(() => {
                                                    const selectors = [
                                                        'dialog.cart-dialog',
                                                        'dialog[part="dialog"]',
                                                        'dialog.shadow',
                                                        'dialog',
                                                        '[role="dialog"]',
                                                        '.cart-dialog',
                                                        'shopify-cart-dialog',
                                                        'div[part="dialog"]',
                                                        'div.cart-dialog'
                                                    ];
                                                    
                                                    let cartDialog = null;
                                                    for (const selector of selectors) {
                                                        cartDialog = cart.shadowRoot.querySelector(selector);
                                                        if (cartDialog) break;
                                                    }
                                                    
                                                    if (cartDialog) {
                                                        // Ensure dialog is visible and properly styled
                                                        cartDialog.setAttribute('open', '');
                                                        cartDialog.style.setProperty('display', 'block', 'important');
                                                        cartDialog.style.setProperty('visibility', 'visible', 'important');
                                                        cartDialog.style.setProperty('opacity', '1', 'important');
                                                        cartDialog.style.setProperty('z-index', '9999', 'important');
                                                        cartDialog.style.setProperty('position', 'fixed', 'important');
                                                        cartDialog.style.setProperty('min-height', '400px', 'important');
                                                        cartDialog.style.setProperty('width', '500px', 'important');
                                                        cartDialog.style.setProperty('max-width', '90vw', 'important');
                                                        cartDialog.style.setProperty('max-height', '90vh', 'important');
                                                        console.log('[ShopifyHtmlHandler] ✅ Ensured cart dialog is visible and styled (async)');
                                                    }
                                                }, 50);
                                            }
                                        } catch (error) {
                                            console.error('[ShopifyHtmlHandler] Error showing cart modal (async):', error);
                                            // Don't let modal error block the UI
                                        }
                                    }, 200);
                                });
                            }).catch((error) => {
                                console.error('[ShopifyHtmlHandler] Error in async addLine promise:', error);
                            });
                        } else {
                            // Synchronous result
                            console.log('[ShopifyHtmlHandler] Item added to cart successfully');
                            // Show cart modal after a brief delay to ensure cart state is updated
                            // Use requestAnimationFrame for better async behavior to prevent UI blocking
                            requestAnimationFrame(() => {
                                setTimeout(() => {
                                    try {
                                        console.log('[ShopifyHtmlHandler] Attempting to show cart modal...');
                                        
                                        // Show the cart root container first (same as view-cart handler)
                                        const cartRoot = document.getElementById('shopify-cart-root');
                                        if (cartRoot) {
                                            cartRoot.style.display = 'block';
                                            console.log('[ShopifyHtmlHandler] ✅ Cart root container shown');
                                        }
                                        
                                        if (result && typeof result.showModal === 'function') {
                                            result.showModal();
                                            console.log('[ShopifyHtmlHandler] Cart modal shown via result');
                                        } else if (cart.showModal) {
                                            cart.showModal();
                                            console.log('[ShopifyHtmlHandler] Cart modal shown via cart.showModal()');
                                        } else {
                                            console.warn('[ShopifyHtmlHandler] No showModal method available on cart or result');
                                        }
                                        
                                        // Ensure the dialog in shadowRoot is visible and styled (same as view-cart handler)
                                        if (cart.shadowRoot) {
                                            setTimeout(() => {
                                                const selectors = [
                                                    'dialog.cart-dialog',
                                                    'dialog[part="dialog"]',
                                                    'dialog.shadow',
                                                    'dialog',
                                                    '[role="dialog"]',
                                                    '.cart-dialog',
                                                    'shopify-cart-dialog',
                                                    'div[part="dialog"]',
                                                    'div.cart-dialog'
                                                ];
                                                
                                                let cartDialog = null;
                                                for (const selector of selectors) {
                                                    cartDialog = cart.shadowRoot.querySelector(selector);
                                                    if (cartDialog) break;
                                                }
                                                
                                                if (cartDialog) {
                                                    // Ensure dialog is visible and properly styled
                                                    cartDialog.setAttribute('open', '');
                                                    cartDialog.style.setProperty('display', 'block', 'important');
                                                    cartDialog.style.setProperty('visibility', 'visible', 'important');
                                                    cartDialog.style.setProperty('opacity', '1', 'important');
                                                    cartDialog.style.setProperty('z-index', '9999', 'important');
                                                    cartDialog.style.setProperty('position', 'fixed', 'important');
                                                    cartDialog.style.setProperty('min-height', '400px', 'important');
                                                    cartDialog.style.setProperty('width', '500px', 'important');
                                                    cartDialog.style.setProperty('max-width', '90vw', 'important');
                                                    cartDialog.style.setProperty('max-height', '90vh', 'important');
                                                    console.log('[ShopifyHtmlHandler] ✅ Ensured cart dialog is visible and styled');
                                                }
                                            }, 50);
                                        }
                                    } catch (error) {
                                        console.error('[ShopifyHtmlHandler] Error showing cart modal:', error);
                                        // Don't let modal error block the UI
                                    }
                                }, 200); // Increased delay to ensure cart state is updated
                            });
                        }
                    } catch (error) {
                        console.error('[ShopifyHtmlHandler] Error adding to cart:', error);
                        console.error('[ShopifyHtmlHandler] Error details:', {
                            message: error.message,
                            stack: error.stack,
                            productContext: !!productContext,
                            productLoaded: !!productContext.product,
                            cartExists: !!cart
                        });
                    }
                }, 10);
                break;
            }

            case 'buy-now': {
                const store = document.querySelector('shopify-store');
                if (store && store.buyNow) {
                    try {
                        store.buyNow(event);
                    } catch (error) {
                        console.error('[ShopifyHtmlHandler] Error with buy now:', error);
                    }
                }
                break;
            }

            case 'view-cart': {
                console.log("🧪 [view-cart] Starting cart search with uniqueId:", uniqueId);
                
                // Search for cart element - try multiple methods since custom elements might not be upgraded yet
                let cart = null;
                
                // Priority 1: Search for singleton cart (shopify-cart.html)
                const cartRoot = document.querySelector('[data-shopify-singleton="true"]');
                if (cartRoot) {
                    cart = cartRoot.querySelector('#shopify-cart') || cartRoot.querySelector('shopify-cart');
                    if (cart) {
                        console.log("🧪 [view-cart] Found cart via Priority 1 (singleton shopify-cart.html):", cart.id);
                    }
                }
                
                // Priority 2: Search by exact ID (works even if not upgraded)
                if (!cart) {
                    cart = document.getElementById('shopify-cart');
                    if (cart) {
                        console.log("🧪 [view-cart] Found cart via Priority 2 (exact #shopify-cart ID):", cart.id);
                    }
                }
                
                // Priority 3: Search by old "cart" ID (backward compatibility)
                if (!cart) {
                    cart = document.getElementById('cart');
                    if (cart && cart.tagName === 'SHOPIFY-CART') {
                        console.log("🧪 [view-cart] Found cart via Priority 3 (id='cart'):", cart.id, "tagName:", cart.tagName);
                    } else {
                        cart = null; // Reset if it's not a shopify-cart
                    }
                }
                
                // Priority 4: Search within popup menu
                if (!cart) {
                    const popupMenu = button.closest('.popup-menu');
                    if (popupMenu) {
                        cart = popupMenu.querySelector('#cart') || popupMenu.querySelector('shopify-cart');
                        if (cart) {
                            console.log("🧪 [view-cart] Found cart via Priority 4 (within popup):", cart.id || 'no-id', "tagName:", cart.tagName);
                        }
                    }
                }
                
                // Priority 5: Search for upgraded custom elements
                if (!cart) {
                    const allCarts = [...document.querySelectorAll("shopify-cart")];
                    if (allCarts.length > 0) {
                        cart = allCarts[0];
                        console.log("🧪 [view-cart] Found cart via Priority 5 (upgraded custom element):", cart.id || 'no-id');
                    }
                }
                
                // Priority 6: Search for any element with tagName shopify-cart (might not be upgraded)
                if (!cart) {
                    const allElements = document.getElementsByTagName('shopify-cart');
                    if (allElements.length > 0) {
                        cart = allElements[0];
                        console.log("🧪 [view-cart] Found cart via Priority 6 (getElementsByTagName):", cart.id || 'no-id', "tagName:", cart.tagName);
                    }
                }
                
                // UUID-based searches removed - we now use singleton cart only
                
                if (cart) {
                    console.log('[ShopifyHtmlHandler] ✅ Cart element found:', cart);
                    console.log('[ShopifyHtmlHandler] Cart ID:', cart.id || 'no-id');
                    console.log('[ShopifyHtmlHandler] Cart tagName:', cart.tagName);
                    console.log('[ShopifyHtmlHandler] Cart has showModal:', typeof cart.showModal === 'function');
                    console.log('[ShopifyHtmlHandler] Cart has shadowRoot:', !!cart.shadowRoot);
                    
                    // Show the cart root container
                    const cartRoot = document.getElementById('shopify-cart-root');
                    if (cartRoot) {
                        cartRoot.style.display = 'block';
                        console.log('[ShopifyHtmlHandler] ✅ Cart root container shown');
                    }
                    
                    // First, try calling showModal() directly on the cart element (Shopify API)
                    if (cart.showModal && typeof cart.showModal === 'function') {
                        try {
                            cart.showModal();
                            console.log('[ShopifyHtmlHandler] ✅ Opened cart via cart.showModal()');
                            
                            // After showModal(), also ensure the dialog in shadowRoot is visible
                            if (cart.shadowRoot) {
                                setTimeout(() => {
                                    const selectors = [
                                        'dialog.cart-dialog',
                                        'dialog[part="dialog"]',
                                        'dialog.shadow',
                                        'dialog',
                                        '[role="dialog"]',
                                        '.cart-dialog',
                                        'shopify-cart-dialog',
                                        'div[part="dialog"]',
                                        'div.cart-dialog'
                                    ];
                                    
                                    let cartDialog = null;
                                    for (const selector of selectors) {
                                        cartDialog = cart.shadowRoot.querySelector(selector);
                                        if (cartDialog) break;
                                    }
                                    
                                    if (cartDialog) {
                                        // Ensure dialog is visible and properly styled
                                        // Use !important to override Shopify's CSS
                                        cartDialog.setAttribute('open', '');
                                        cartDialog.style.setProperty('display', 'block', 'important');
                                        cartDialog.style.setProperty('visibility', 'visible', 'important');
                                        cartDialog.style.setProperty('opacity', '1', 'important');
                                        cartDialog.style.setProperty('z-index', '9999', 'important');
                                        cartDialog.style.setProperty('position', 'fixed', 'important');
                                        cartDialog.style.setProperty('min-height', '400px', 'important');
                                        cartDialog.style.setProperty('width', '500px', 'important');
                                        cartDialog.style.setProperty('max-width', '90vw', 'important');
                                        cartDialog.style.setProperty('max-height', '90vh', 'important');
                                        cartDialog.style.setProperty('overflow', 'auto', 'important');
                                        cartDialog.style.setProperty('background-color', 'white', 'important');
                                        cartDialog.style.setProperty('padding', '20px', 'important');
                                        cartDialog.style.setProperty('border-radius', '8px', 'important');
                                        cartDialog.style.setProperty('box-shadow', '0 4px 6px rgba(0, 0, 0, 0.1)', 'important');
                                        console.log('[ShopifyHtmlHandler] ✅ Ensured cart dialog is visible and styled');
                                    } else {
                                        console.warn('[ShopifyHtmlHandler] No dialog found in shadowRoot after showModal()');
                                    }
                                }, 50);
                            }
                            break;
                        } catch (e) {
                            console.warn('[ShopifyHtmlHandler] cart.showModal() failed:', e);
                        }
                    }
                    
                    // If showModal() doesn't exist or failed, try accessing shadowRoot
                    if (cart.shadowRoot) {
                        const selectors = [
                            'dialog.cart-dialog',
                            'dialog[part="dialog"]',
                            'dialog.shadow',
                            'dialog',
                            '[role="dialog"]',
                            '.cart-dialog',
                            'shopify-cart-dialog',
                            'div[part="dialog"]',
                            'div.cart-dialog'
                        ];
                        
                        let cartDialog = null;
                        for (const selector of selectors) {
                            cartDialog = cart.shadowRoot.querySelector(selector);
                            if (cartDialog) break;
                        }
                        
                        if (cartDialog) {
                            if (cartDialog.showModal && typeof cartDialog.showModal === 'function') {
                                try {
                                    cartDialog.showModal();
                                    console.log('[ShopifyHtmlHandler] ✅ Opened cart dialog via showModal()');
                                    if (cartDialog.offsetHeight === 0) {
                                        cartDialog.style.minHeight = '400px';
                                        cartDialog.style.width = '500px';
                                        cartDialog.style.maxWidth = '90vw';
                                    }
                                    break;
                                } catch (e) {
                                    console.warn('[ShopifyHtmlHandler] showModal() failed:', e);
                                }
                            }
                            
                            // Use !important to override Shopify's CSS
                            cartDialog.setAttribute('open', '');
                            cartDialog.style.setProperty('display', 'block', 'important');
                            cartDialog.style.setProperty('visibility', 'visible', 'important');
                            cartDialog.style.setProperty('opacity', '1', 'important');
                            cartDialog.style.setProperty('z-index', '9999', 'important');
                            cartDialog.style.setProperty('position', 'fixed', 'important');
                            cartDialog.style.setProperty('min-height', '400px', 'important');
                            cartDialog.style.setProperty('width', '500px', 'important');
                            cartDialog.style.setProperty('max-width', '90vw', 'important');
                            cartDialog.style.setProperty('max-height', '90vh', 'important');
                            cartDialog.style.setProperty('overflow', 'auto', 'important');
                            cartDialog.style.setProperty('background-color', 'white', 'important');
                            cartDialog.style.setProperty('padding', '20px', 'important');
                            cartDialog.style.setProperty('border-radius', '8px', 'important');
                            cartDialog.style.setProperty('box-shadow', '0 4px 6px rgba(0, 0, 0, 0.1)', 'important');
                            console.log('[ShopifyHtmlHandler] ✅ Opened cart dialog via attributes');
                        } else {
                            console.warn('[ShopifyHtmlHandler] No dialog found in cart shadowRoot');
                        }
                    } else {
                        console.warn('[ShopifyHtmlHandler] Cart element has no shadowRoot - may not be upgraded yet');
                        // Wait a bit and retry if cart hasn't been upgraded yet
                        setTimeout(() => {
                            if (cart.showModal && typeof cart.showModal === 'function') {
                                try {
                                    cart.showModal();
                                    console.log('[ShopifyHtmlHandler] ✅ Opened cart via cart.showModal() (retry)');
                                } catch (e) {
                                    console.warn('[ShopifyHtmlHandler] cart.showModal() failed on retry:', e);
                                }
                            } else if (cart.shadowRoot) {
                                // Retry shadowRoot approach
                                const dialog = cart.shadowRoot.querySelector('dialog');
                                if (dialog && dialog.showModal) {
                                    try {
                                        dialog.showModal();
                                        console.log('[ShopifyHtmlHandler] ✅ Opened cart dialog via showModal() (retry)');
                                    } catch (e) {
                                        console.warn('[ShopifyHtmlHandler] Dialog showModal() failed on retry:', e);
                                    }
                                }
                            }
                        }, 100);
                    }
                    
                    // Fallback: set attributes on cart element
                    cart.setAttribute('open', '');
                    cart.style.display = 'block';
                    cart.style.visibility = 'visible';
                } else {
                    console.warn('[ShopifyHtmlHandler] Cart not found for view-cart action');
                    console.warn('[ShopifyHtmlHandler] Searched for: singleton cart (#shopify-cart), #cart, shopify-cart elements');
                    // Log all elements with "cart" in their ID for debugging
                    const allCartIds = [...document.querySelectorAll('[id*="cart"]')].map(el => ({
                        id: el.id,
                        tagName: el.tagName,
                        className: el.className
                    }));
                    if (allCartIds.length > 0) {
                        console.log('[ShopifyHtmlHandler] Found elements with "cart" in ID:', allCartIds);
                    }
                }
                break;
            }
        }
    }

    /**
     * Binds event listeners to Shopify buttons using data attributes.
     * Uses document-level event delegation.
     * 
     * @param {HTMLElement} container - The container element (not used, kept for compatibility)
     */
    bindShopifyEvents(container) {
        if (ShopifyHtmlHandler.shopifyEventsBound) {
            return;
        }

        ShopifyHtmlHandler.shopifyEventsBound = true;
        console.log("[ShopifyHtmlHandler] Setting up GLOBAL document-level Shopify event delegation");

        document.addEventListener('click', (event) => {
            const button = event.target.closest('[data-custom-shopify-action]');
            if (!button) return;

            console.log("[ShopifyHtmlHandler] CLICK detected on:", event.target);
            console.log("[ShopifyHtmlHandler] Button found:", button);
            console.log("[ShopifyHtmlHandler] Action:", button.getAttribute('data-custom-shopify-action'));

            event.preventDefault();
            event.stopPropagation();

            const uniqueId = ShopifyHtmlHandler.extractUniqueIdFromContext(button);
            ShopifyHtmlHandler.handleShopifyClick(event, button, uniqueId);
        });
        
        // Country/Currency selector - document-level event delegation
        // Inline scripts in popup-menu-shopify.html don't execute when injected via innerHTML
        // Note: ID might be uniquified (country-selector-{guid}) so we check with startsWith
        document.addEventListener('change', (event) => {
            const selector = event.target;
            // Check by class OR by ID (which might be uniquified)
            const isCountrySelector = selector && (
                selector.classList.contains('product-modal__country-selector') ||
                selector.id === 'country-selector' ||
                (selector.id && selector.id.startsWith('country-selector'))
            );
            
            if (!isCountrySelector) return;
            
            const countryCode = selector.value;
            console.log('[ShopifyHtmlHandler] Country selector changed to:', countryCode, 'selector:', selector);
            
            // Save preference to localStorage
            const countryKey = ShopifyConfig.localStorageCountryKey;
            const currentCountry = localStorage.getItem(countryKey) || ShopifyConfig.defaultCountryCode;
            console.log('[ShopifyHtmlHandler] Current country:', currentCountry, 'New country:', countryCode);
            if (currentCountry === countryCode) {
                console.log('[ShopifyHtmlHandler] Same country, skipping');
                return;
            }
            
            localStorage.setItem(countryKey, countryCode);
            console.log('[ShopifyHtmlHandler] Currency preference saved:', countryCode);
            
            // Find and update the shopify-store element
            const shopifyStore = document.getElementById('shopify-store-element');
            console.log('[ShopifyHtmlHandler] Found shopify-store:', !!shopifyStore);
            if (shopifyStore) {
                shopifyStore.setAttribute('country', countryCode);
            }
            
            // Rebuild the shopify container to reload with new currency
            const shopifyContainer = selector.closest('.shopify-container');
            console.log('[ShopifyHtmlHandler] Found shopify-container:', !!shopifyContainer);
            if (shopifyContainer) {
                const parent = shopifyContainer.parentElement;
                const productContext = shopifyContainer.querySelector('shopify-context[type="product"]');
                const productHandle = productContext ? productContext.getAttribute('handle') : null;
                
                // Store modal state
                const modal = shopifyContainer.querySelector('.product-modal');
                const wasModalOpen = modal && modal.open;
                
                // Remove old container
                shopifyContainer.remove();
                
                // Create new container with updated country
                const newContainer = document.createElement('div');
                newContainer.className = 'shopify-container';
                
                // Build new shopify-store with updated country
                const storeHtml = ShopifyHtmlHandler.buildStoreHtml(countryCode);
                
                // Build product layout HTML
                const handle = productHandle || ShopifyConfig.fallbackProductHandle;
                const productHtml = ShopifyHtmlHandler.getProductLayoutHTML(handle, countryCode);
                
                newContainer.innerHTML = storeHtml + productHtml;
                
                ShopifyHtmlHandler.ensureWebComponentsScript();
                
                parent.insertBefore(newContainer, parent.firstChild);
                
                // Re-open modal after components load
                if (wasModalOpen) {
                    setTimeout(() => {
                        const newModal = newContainer.querySelector('.product-modal');
                        if (newModal) {
                            newModal.showModal();
                            console.log('[ShopifyHtmlHandler] Modal reopened with new currency');
                        }
                        
                        // Set dropdown value
                        const newSelector = newContainer.querySelector('#country-selector');
                        if (newSelector) {
                            newSelector.value = countryCode;
                        }
                    }, 1000);
                }
                
                console.log('[ShopifyHtmlHandler] Shopify container reloaded with country:', countryCode);
            }
        }, true);
        
        // Initialize country selector value from localStorage on page load
        setTimeout(() => {
            const savedCountry = localStorage.getItem(ShopifyConfig.localStorageCountryKey);
            console.log('[ShopifyHtmlHandler] Init - saved country from localStorage:', savedCountry);
            
            if (savedCountry) {
                // Find selector by class (since ID might be uniquified)
                const selectors = document.querySelectorAll('.product-modal__country-selector');
                console.log('[ShopifyHtmlHandler] Found country selectors:', selectors.length);
                selectors.forEach(selector => {
                    selector.value = savedCountry;
                    console.log('[ShopifyHtmlHandler] Set country selector to saved value:', savedCountry);
                });
                
                // Also update shopify-store element if it exists
                const shopifyStore = document.getElementById('shopify-store-element');
                if (shopifyStore && shopifyStore.getAttribute('country') !== savedCountry) {
                    shopifyStore.setAttribute('country', savedCountry);
                    console.log('[ShopifyHtmlHandler] Applied saved country to store:', savedCountry);
                }
            }
        }, 1000);
        
        // Force show scrollbars on macOS (where they're hidden by default)
        this.forceShowScrollbars();
        
        // Also set up direct listener on country selectors as they appear
        // (fallback in case document-level delegation doesn't work)
        this.setupCountrySelectorWatcher();
    }
    
    /**
     * Watches for country selectors and attaches direct event listeners
     * This is a fallback in case document-level event delegation doesn't work
     */
    setupCountrySelectorWatcher() {
        const attachListener = (selector) => {
            if (selector.dataset.listenerAttached) return;
            
            selector.addEventListener('change', (e) => {
                console.log('[ShopifyHtmlHandler] Direct listener - country changed:', e.target.value);
                this.handleCountryChange(e.target);
            });
            selector.dataset.listenerAttached = 'true';
            console.log('[ShopifyHtmlHandler] Attached direct listener to country selector');
        };
        
        // Check existing selectors
        const existingSelectors = document.querySelectorAll('.product-modal__country-selector');
        existingSelectors.forEach(attachListener);
        
        // Watch for new selectors
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) {
                        if (node.classList && node.classList.contains('product-modal__country-selector')) {
                            attachListener(node);
                        }
                        if (node.querySelectorAll) {
                            node.querySelectorAll('.product-modal__country-selector').forEach(attachListener);
                        }
                    }
                });
            });
        });
        
        observer.observe(document.body, { childList: true, subtree: true });
        console.log('[ShopifyHtmlHandler] Country selector watcher set up');
    }
    
    /**
     * Handles country change from the selector
     * @param {HTMLSelectElement} selector - The country selector element
     */
    handleCountryChange(selector) {
        const countryCode = selector.value;
        console.log('[ShopifyHtmlHandler] handleCountryChange called with:', countryCode);
        
        const countryKey = ShopifyConfig.localStorageCountryKey;
        const currentCountry = localStorage.getItem(countryKey) || ShopifyConfig.defaultCountryCode;
        if (currentCountry === countryCode) {
            console.log('[ShopifyHtmlHandler] Same country, skipping');
            return;
        }
        
        localStorage.setItem(countryKey, countryCode);
        console.log('[ShopifyHtmlHandler] Currency preference saved:', countryCode);
        
        // Find the shopify container and rebuild it
        const shopifyContainer = selector.closest('.shopify-container');
        if (!shopifyContainer) {
            console.warn('[ShopifyHtmlHandler] Could not find .shopify-container');
            return;
        }
        
        const parent = shopifyContainer.parentElement;
        const productContext = shopifyContainer.querySelector('shopify-context[type="product"]');
        const productHandle = productContext ? productContext.getAttribute('handle') : null;
        
        // Store modal state
        const modal = shopifyContainer.querySelector('.product-modal') || 
                     shopifyContainer.querySelector('dialog');
        const wasModalOpen = modal && modal.open;
        
        console.log('[ShopifyHtmlHandler] Rebuilding container:', {
            parent: !!parent,
            productHandle,
            wasModalOpen
        });
        
        // Remove old container
        shopifyContainer.remove();
        
        // Create new container with updated country
        const newContainer = document.createElement('div');
        newContainer.className = 'shopify-container';
        
        // Build new content
        const handle = productHandle || ShopifyConfig.fallbackProductHandle;
        const storeHtml = ShopifyHtmlHandler.buildStoreHtml(countryCode);
        const productHtml = ShopifyHtmlHandler.getProductLayoutHTML(handle, countryCode);
        
        newContainer.innerHTML = storeHtml + productHtml;
        parent.insertBefore(newContainer, parent.firstChild);
        
        console.log('[ShopifyHtmlHandler] New container created');
        
        // Re-open modal after components load
        if (wasModalOpen) {
            setTimeout(() => {
                const newModal = newContainer.querySelector('.product-modal') ||
                               newContainer.querySelector('dialog');
                if (newModal && newModal.showModal) {
                    newModal.showModal();
                    console.log('[ShopifyHtmlHandler] Modal reopened');
                }
                
                // Set dropdown value
                const newSelector = newContainer.querySelector('.product-modal__country-selector');
                if (newSelector) {
                    newSelector.value = countryCode;
                }
            }, 1000);
        }
    }
    
    /**
     * Checks if scrollbars are visible and forces them to show if hidden (macOS).
     * Creates a test element to detect if scrollbars take up space.
     */
    forceShowScrollbars() {
        console.log('[ShopifyHtmlHandler] Setting up scrollbar visibility fix');
        
        // Check immediately if body is ready, otherwise wait for load
        const applyScrollbarFix = () => {
            const scrollbarsVisible = ShopifyHtmlHandler.areScrollbarsVisible();
            console.log('[ShopifyHtmlHandler] Scrollbars visible:', scrollbarsVisible);
            
            if (!scrollbarsVisible) {
                document.body.classList.add('force-show-scrollbars');
                console.log('[ShopifyHtmlHandler] Added force-show-scrollbars class to body');
                
                // Also add to modal containers specifically
                const modalContainers = document.querySelectorAll('.product-modal__container');
                console.log('[ShopifyHtmlHandler] Found modal containers:', modalContainers.length);
                modalContainers.forEach(container => {
                    container.classList.add('force-show-scrollbars');
                });
            }
        };
        
        if (document.body) {
            applyScrollbarFix();
        } else {
            window.addEventListener('load', applyScrollbarFix);
        }
        
        // Also apply when modals are opened (they might be added dynamically)
        document.addEventListener('click', (event) => {
            const button = event.target.closest('[data-custom-shopify-action="open-modal"]') ||
                          event.target.closest('[data-custom-shopify-action="view-product"]');
            if (button) {
                setTimeout(() => {
                    if (!ShopifyHtmlHandler.areScrollbarsVisible()) {
                        const modalContainers = document.querySelectorAll('.product-modal__container');
                        modalContainers.forEach(container => {
                            container.classList.add('force-show-scrollbars');
                            console.log('[ShopifyHtmlHandler] Added force-show-scrollbars to modal container');
                        });
                    }
                }, 100);
            }
        });
    }
    
    /**
     * Returns whether scrollbars show up on scrollable elements.
     * This is false on Macs when the "General > Show scroll bars" setting is
     * not set to "Always" (the default is "When scrolling").
     * @returns {boolean} True if scrollbars are visible
     */
    static areScrollbarsVisible() {
        if (!document.body) return true; // Assume visible if body not ready
        
        const scrollableElem = document.createElement('div');
        const innerElem = document.createElement('div');
        scrollableElem.style.width = '30px';
        scrollableElem.style.height = '30px';
        scrollableElem.style.overflow = 'scroll';
        scrollableElem.style.borderWidth = '0';
        scrollableElem.style.position = 'absolute';
        scrollableElem.style.top = '-100px';
        scrollableElem.style.left = '-100px';
        innerElem.style.width = '30px';
        innerElem.style.height = '60px';
        scrollableElem.appendChild(innerElem);
        document.body.appendChild(scrollableElem);
        const diff = scrollableElem.offsetWidth - scrollableElem.clientWidth;
        document.body.removeChild(scrollableElem);
        return diff > 0;
    }
    
    /**
     * Generates the product layout HTML for rebuilding the shopify container
     * The content inside shopify-context MUST be wrapped in a <template> element
     * @param {string} handle - The product handle
     * @param {string} countryCode - The country code for currency
     * @returns {string} The product layout HTML
     */
    static getProductLayoutHTML(handle, countryCode) {
        // IMPORTANT: Content inside shopify-context must be wrapped in <template>
        return '<div class="product-layout">' +
            '<div class="product-card">' +
                '<shopify-context id="shopify-product-card" type="product" handle="' + handle + '">' +
                    '<template>' +
                        '<div class="product-card__container">' +
                            '<div class="product-card__media">' +
                                '<div class="product-card__main-image">' +
                                    '<shopify-media width="280" height="280" query="product.selectedOrFirstAvailableVariant.image"></shopify-media>' +
                                '</div>' +
                            '</div>' +
                            '<div class="product-card__details">' +
                                '<div class="product-card__info">' +
                                    '<h2 class="product-card__title"><shopify-data query="product.title"></shopify-data></h2>' +
                                    '<div class="product-card__price"><shopify-money query="product.selectedOrFirstAvailableVariant.price"></shopify-money></div>' +
                                '</div>' +
                                '<button data-custom-shopify-action="open-modal">View product</button>' +
                            '</div>' +
                        '</div>' +
                        '<dialog id="product-modal" class="product-modal">' +
                            '<div class="product-modal__container">' +
                                '<div class="product-modal__close-container">' +
                                    '<button class="product-modal__close" data-custom-shopify-action="close-modal">&#10005;</button>' +
                                '</div>' +
                                '<div class="product-modal__content">' +
                                    '<div class="product-modal__layout">' +
                                        '<div class="product-modal__media">' +
                                            '<div class="product-modal__main-image">' +
                                                '<shopify-media width="416" height="416" query="product.selectedOrFirstAvailableVariant.image"></shopify-media>' +
                                            '</div>' +
                                        '</div>' +
                                        '<div class="product-modal__details">' +
                                            '<div class="product-modal__header">' +
                                                '<div><span class="product-modal__vendor"><shopify-data query="product.vendor"></shopify-data></span></div>' +
                                                '<h1 class="product-modal__title"><shopify-data query="product.title"></shopify-data></h1>' +
                                                '<div class="product-modal__price-row">' +
                                                    '<div class="product-modal__price-container">' +
                                                        '<shopify-money query="product.selectedOrFirstAvailableVariant.price"></shopify-money>' +
                                                        '<shopify-money class="product-modal__compare-price" query="product.selectedOrFirstAvailableVariant.compareAtPrice"></shopify-money>' +
                                                    '</div>' +
                                                    '<select id="country-selector" class="product-modal__country-selector">' +
                                                        ShopifyHtmlHandler.buildCountryOptionsHtml(countryCode) +
                                                    '</select>' +
                                                '</div>' +
                                            '</div>' +
                                            '<shopify-variant-selector></shopify-variant-selector>' +
                                            '<div class="product-modal__buttons">' +
                                                '<button class="product-modal__add-button" data-custom-shopify-action="add-to-cart" shopify-attr--disabled="!product.selectedOrFirstAvailableVariant.availableForSale">Add to cart</button>' +
                                                '<button class="product-modal__buy-button" data-custom-shopify-action="buy-now" shopify-attr--disabled="!product.selectedOrFirstAvailableVariant.availableForSale">Buy now</button>' +
                                            '</div>' +
                                        '</div>' +
                                    '</div>' +
                                    '<p class="product-modal__description-text"><shopify-data query="product.descriptionHtml" unsafe></shopify-data></p>' +
                                '</div>' +
                                '<div class="product-modal__cart-feedback" style="display: none;">' +
                                    '<span class="product-modal__cart-message">Added to cart!</span>' +
                                    '<a href="#" data-custom-shopify-action="view-cart">View Cart</a>' +
                                '</div>' +
                            '</div>' +
                        '</dialog>' +
                    '</template>' +
                '</shopify-context>' +
            '</div>' +
        '</div>';
    }

    /**
     * Event-driven approach to wait for Shopify components to upgrade and hydrate.
     * Uses events and MutationObserver instead of polling.
     */
    waitForComponentHydration() {
        const contexts = document.querySelectorAll('shopify-context[type="product"]');
        
        if (contexts.length === 0) {
            // No contexts yet, wait for them to be added
            const observer = new MutationObserver(() => {
                const newContexts = document.querySelectorAll('shopify-context[type="product"]');
                if (newContexts.length > 0) {
                    observer.disconnect();
                    this.waitForComponentHydration();
                }
            });
            observer.observe(document.body, { childList: true, subtree: true });
            
            // Fallback timeout
            setTimeout(() => {
                observer.disconnect();
                if (document.querySelectorAll('shopify-context[type="product"]').length === 0) {
                    console.warn('[ShopifyHtmlHandler] No product contexts found after waiting');
                    this.verifyHydrationStatus();
                } else {
                    this.waitForComponentHydration();
                }
            }, 2000);
            return;
        }
        
        // Track which contexts have been upgraded
        const upgradedContexts = new Set();
        const allContexts = Array.from(contexts);
        
        // Check if components are already upgraded
        const checkUpgradeStatus = () => {
            allContexts.forEach(ctx => {
                if (ctx.shadowRoot !== null) {
                    upgradedContexts.add(ctx);
                }
            });
            
            if (upgradedContexts.size === allContexts.length) {
                // All upgraded, proceed with verification
                this.onComponentsUpgraded(allContexts);
                return true;
            }
            return false;
        };
        
        // Check immediately
        if (checkUpgradeStatus()) {
            return;
        }
        
        // Listen for shopify-components-ready event
        const onComponentsReady = () => {
            console.log('[ShopifyHtmlHandler] shopify-components-ready event received');
            // Give components a moment to upgrade after the event
            setTimeout(() => {
                if (checkUpgradeStatus()) {
                    window.removeEventListener('shopify-components-ready', onComponentsReady);
                }
            }, 100);
        };
        
        window.addEventListener('shopify-components-ready', onComponentsReady);
        
        // Use MutationObserver to watch for shadowRoot creation
        const shadowObserver = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1) {
                            // Check if this node or its children are shopify-context
                            const contextNodes = node.tagName === 'SHOPIFY-CONTEXT' ? [node] : 
                                               node.querySelectorAll?.('shopify-context[type="product"]') || [];
                            contextNodes.forEach(ctx => {
                                if (ctx.shadowRoot !== null && !upgradedContexts.has(ctx)) {
                                    upgradedContexts.add(ctx);
                                    console.log('[ShopifyHtmlHandler] Context upgraded (shadowRoot detected):', ctx.getAttribute('handle'));
                                    
                                    if (upgradedContexts.size === allContexts.length) {
                                        shadowObserver.disconnect();
                                        window.removeEventListener('shopify-components-ready', onComponentsReady);
                                        this.onComponentsUpgraded(allContexts);
                                    }
                                }
                            });
                        }
                    });
                }
            });
        });
        
        // Watch for attribute changes (shadowRoot might be added as an attribute change)
        const attributeObserver = new MutationObserver((mutations) => {
            allContexts.forEach(ctx => {
                if (ctx.shadowRoot !== null && !upgradedContexts.has(ctx)) {
                    upgradedContexts.add(ctx);
                    console.log('[ShopifyHtmlHandler] Context upgraded (attribute change detected):', ctx.getAttribute('handle'));
                    
                    if (upgradedContexts.size === allContexts.length) {
                        shadowObserver.disconnect();
                        attributeObserver.disconnect();
                        window.removeEventListener('shopify-components-ready', onComponentsReady);
                        this.onComponentsUpgraded(allContexts);
                    }
                }
            });
        });
        
        // Observe all contexts for shadowRoot creation
        allContexts.forEach(ctx => {
            shadowObserver.observe(ctx, { childList: true, subtree: true });
            attributeObserver.observe(ctx, { attributes: true, attributeFilter: [] });
        });
        
        // Fallback: Check periodically if events are missed (but less frequently)
        let fallbackCount = 0;
        const maxFallbackChecks = 10; // 10 * 500ms = 5 seconds max
        const fallbackInterval = setInterval(() => {
            fallbackCount++;
            if (checkUpgradeStatus()) {
                clearInterval(fallbackInterval);
                shadowObserver.disconnect();
                attributeObserver.disconnect();
                window.removeEventListener('shopify-components-ready', onComponentsReady);
            } else if (fallbackCount >= maxFallbackChecks) {
                clearInterval(fallbackInterval);
                shadowObserver.disconnect();
                attributeObserver.disconnect();
                window.removeEventListener('shopify-components-ready', onComponentsReady);
                console.warn('[ShopifyHtmlHandler] Fallback timeout reached, verifying anyway');
                this.verifyHydrationStatus();
            }
        }, 500);
        
        // Store observers for cleanup
        this.componentHydrationObservers = [shadowObserver, attributeObserver];
        this.componentHydrationCleanup = () => {
            clearInterval(fallbackInterval);
            shadowObserver.disconnect();
            attributeObserver.disconnect();
            window.removeEventListener('shopify-components-ready', onComponentsReady);
        };
    }
    
    /**
     * Called when all components are upgraded. Performs verification and price checking.
     */
    onComponentsUpgraded(contexts) {
        console.log('[ShopifyHtmlHandler] All components upgraded, verifying hydration');
        this.verifyHydrationStatus();
        
        // Wait for components to fetch product data, then check prices
        setTimeout(() => {
            contexts.forEach((ctx, index) => {
                const priceElement = ctx.querySelector('shopify-money[query*="price"]');
                const priceText = priceElement?.textContent?.trim();
                console.log(`[ShopifyHtmlHandler] Context ${index + 1} price check:`, {
                    handle: ctx.getAttribute('handle'),
                    priceText: priceText || 'not loaded yet',
                    hasPriceElement: !!priceElement,
                    hasShadowRoot: !!ctx.shadowRoot
                });
            });
        }, 500);
    }
    
    /**
     * Verifies cart singleton status. Runs independently of product context hydration.
     */
    verifyCartSingleton() {
        // Wait a bit for cart to be injected and upgraded
        setTimeout(() => {
            const allCarts = document.querySelectorAll('shopify-cart');
            if (allCarts.length > 1) {
                console.warn(`[ShopifyHtmlHandler] ⚠️ WARNING: Found ${allCarts.length} shopify-cart elements! Expected 1.`, 
                    Array.from(allCarts).map(c => ({ id: c.id, parent: c.parentElement?.id || c.parentElement?.getAttribute('data-shopify-singleton') || 'none' }))
                );
            } else if (allCarts.length === 1) {
                console.log('[ShopifyHtmlHandler] ✅ Verified: Exactly 1 shopify-cart element found');
                const cartRoot = document.querySelector('[data-shopify-singleton="true"]');
                if (cartRoot) {
                    console.log('[ShopifyHtmlHandler] ✅ Singleton cart root found');
                    
                    // Wire up close behavior
                    this.wireCartCloseBehavior();
                } else {
                    console.warn('[ShopifyHtmlHandler] ⚠️ Cart found but singleton root not found');
                }
            } else {
                console.warn('[ShopifyHtmlHandler] ⚠️ WARNING: No shopify-cart elements found!');
            }
        }, 500);
    }

    /**
     * Verifies hydration status of Shopify components after injection.
     * Logs diagnostic information about shadow roots and handles.
     */
    verifyHydrationStatus() {
        console.log("[ShopifyHtmlHandler] === HYDRATION VERIFICATION ===");
        
        // Check store
        const store = document.querySelector('shopify-store');
        console.log("[ShopifyHtmlHandler] Store:", {
            exists: !!store,
            hasShadowRoot: !!store?.shadowRoot,
            attributes: store ? Array.from(store.attributes).map(a => `${a.name}="${a.value}"`) : []
        });
        
        // Check cart (singleton)
        const cartRoot = document.querySelector('[data-shopify-singleton="true"]');
        const cart = cartRoot ? 
            (cartRoot.querySelector('#shopify-cart') || cartRoot.querySelector('shopify-cart')) :
            document.querySelector('#shopify-cart') || document.querySelector('shopify-cart');
        console.log("[ShopifyHtmlHandler] Cart:", {
            exists: !!cart,
            hasShadowRoot: !!cart?.shadowRoot,
            id: cart?.id,
            isSingleton: !!cartRoot
        });
        
        // Check all contexts
        const contexts = document.querySelectorAll('shopify-context');
        console.log("[ShopifyHtmlHandler] Contexts found:", contexts.length);
        contexts.forEach((ctx, index) => {
            console.log(`[ShopifyHtmlHandler] Context ${index + 1}:`, {
                id: ctx.id,
                handle: ctx.getAttribute('handle'),
                hasShadowRoot: !!ctx.shadowRoot,
                type: ctx.getAttribute('type')
            });
        });
        
        // Check for placeholder-product
        const placeholders = Array.from(contexts).filter(ctx => 
            ctx.getAttribute('handle') === 'placeholder-product'
        );
        if (placeholders.length > 0) {
            console.warn(`[ShopifyHtmlHandler] ⚠️ Found ${placeholders.length} contexts with placeholder-product handle:`, 
                placeholders.map(p => p.id));
        } else {
            console.log("[ShopifyHtmlHandler] ✅ No placeholder-product handles found (good!)");
        }
        
        // ✅ DIAGNOSTIC: Explicit product context count and state
        const productContexts = document.querySelectorAll('shopify-context[type="product"]');
        console.log('[ShopifyHtmlHandler] ⚠️ DIAGNOSTIC: Product context count:', productContexts.length);
        if (productContexts.length > 1) {
            console.warn('[ShopifyHtmlHandler] ⚠️ MULTIPLE PRODUCT CONTEXTS DETECTED - This will cause GraphQL conflicts!');
            productContexts.forEach((ctx, idx) => {
                console.warn(`[ShopifyHtmlHandler] Context ${idx + 1}:`, {
                    id: ctx.id,
                    handle: ctx.getAttribute('handle'),
                    product: ctx.product === null ? 'NULL (hydration failed)' : 'hydrated'
                });
            });
        }
        
        console.log("[ShopifyHtmlHandler] === END VERIFICATION ===");
    }

    /**
     * Wires up cart close behavior to hide the cart root container when cart closes.
     * Must be called after cart element is upgraded.
     */
    wireCartCloseBehavior() {
        const cartRoot = document.getElementById('shopify-cart-root');
        const cart = document.getElementById('shopify-cart');

        if (!cart || !cartRoot) {
            console.warn('[ShopifyHtmlHandler] Cannot wire cart close behavior - cart or root not found');
            return;
        }

        // Shopify emits events when cart UI closes
        const handleClose = () => {
            cartRoot.style.display = 'none';
            console.log('[ShopifyHtmlHandler] Cart closed, hiding cart root');
        };

        cart.addEventListener('close', handleClose);
        cart.addEventListener('cart:close', handleClose);

        // Shadow DOM dialog fallback - listen for dialog close
        if (cart.shadowRoot) {
            const dialog = cart.shadowRoot.querySelector('dialog');
            if (dialog) {
                dialog.addEventListener('close', handleClose);
                console.log('[ShopifyHtmlHandler] Wired dialog close listener');
            }
        }

        console.log('[ShopifyHtmlHandler] ✅ Cart close behavior wired');
    }

    /**
     * Cleanup when script is destroyed. (TASK 7)
     */
    destroy() {
        // Remove popup root from DOM
        if (this.popupRootEl && this.popupRootEl.parentElement) {
            this.popupRootEl.remove();
            console.log('[ShopifyHtmlHandler] Removed popup root from DOM on destroy');
        }
        
        if (this.shopifyButtonObserver) {
            this.shopifyButtonObserver.disconnect();
        }
        if (this.componentHydrationCleanup) {
            this.componentHydrationCleanup();
        }
        if (this.componentHydrationObservers) {
            this.componentHydrationObservers.forEach(observer => {
                if (observer && observer.disconnect) {
                    observer.disconnect();
                }
            });
        }
        super.destroy?.();
    }
}
