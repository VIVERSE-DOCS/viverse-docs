/**
 * Example Shopify configuration for PlayCanvas + Shopify Web Components.
 *
 * Setup:
 * 1. Copy this file to shopify-config.mjs (same folder).
 * 2. Replace placeholder values with your store settings.
 * 3. Do not put Admin API tokens in this file.
 *
 * Per-product handles are set on each entity's shopifyProductHandler script
 * (productHandle attribute), not in this file.
 */
export const ShopifyConfig = {
    // /** Public store URL for <shopify-store store-domain="..."> */
    // storeDomain: 'https://YOUR_SHOPIFY_STORE/',

    // /** Shopify Web Components CDN (usually leave unchanged) */
    // webComponentsCdnUrl: 'https://cdn.shopify.com/storefront/web-components.js',

    // defaultCountryCode: 'US',
    // defaultLanguageCode: 'en',

    // /** Used when country-rebuild cannot read a product handle from the DOM */
    // fallbackProductHandle: 'YOUR_DEFAULT_PRODUCT_HANDLE',

    // localStorageCountryKey: 'shopify-country',

    // supportedCountries: [
    //     { code: 'US', label: 'USD' },
    //     { code: 'CA', label: 'CAD' },
    //     { code: 'GB', label: 'GBP' },
    //     { code: 'AU', label: 'AUD' },
    //     { code: 'EU', label: 'EUR' },
    //     { code: 'JP', label: 'JPY' }
    // ],

    // /**
    //  * NOT USED by Shopify Web Components integration.
    //  * Included for reference only if you migrate to raw Storefront API later.
    //  * Use a server-side proxy — never put tokens in PlayCanvas client scripts.
    //  */
    // storefrontAccessToken: null,
    // apiVersion: null

    storeDomain: 'https://darkgableclothing.com/',
    webComponentsCdnUrl: 'https://cdn.shopify.com/storefront/web-components.js',
    defaultCountryCode: 'US',
    defaultLanguageCode: 'en',
    fallbackProductHandle: 'ladies-gtjd-tank',
    localStorageCountryKey: 'shopify-country',
    supportedCountries: [
        { code: 'US', label: 'USD' },
        { code: 'CA', label: 'CAD' },
        { code: 'GB', label: 'GBP' },
        { code: 'AU', label: 'AUD' },
        { code: 'EU', label: 'EUR' },
        { code: 'JP', label: 'JPY' }
    ],
    storefrontAccessToken: null,
    apiVersion: null
};
