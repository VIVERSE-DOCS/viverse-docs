import { Script } from 'playcanvas';
import { CameraService } from '../../@viverse/create-sdk.mjs';

/**
 * Controls camera zoom based on popup state.
 * Listens to popup:open / popup:close events and disables camera zoom when popups are open.
 * 
 * Attach this script to any entity (e.g., same entity as HtmlHandler or PopupWheelBlocker).
 */
export class PopupCameraController extends Script {

    static scriptName = 'popupCameraController';

    /**
     * Called when the script is about to run for the first time.
     */
    initialize() {
        this.cameraService = new CameraService();
        
        this.app.on('popup:open', this.onPopupOpen, this);
        this.app.on('popup:close', this.onPopupClose, this);
        
        console.log('[PopupCameraController] Listening for popup events');
    }

    onPopupOpen() {
        this.cameraService.canZoom = false;
        console.log('[PopupCameraController] Popup opened - camera zoom disabled');
    }

    onPopupClose() {
        this.cameraService.canZoom = true;
        console.log('[PopupCameraController] Popup closed - camera zoom enabled');
    }

    /**
     * Cleanup event listeners on destroy
     */
    destroy() {
        this.app.off('popup:open', this.onPopupOpen, this);
        this.app.off('popup:close', this.onPopupClose, this);
    }
}

