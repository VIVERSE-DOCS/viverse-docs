import { Script } from 'playcanvas';
import { TriggerTypes } from '../../@viverse/create-extensions-sdk.mjs';

/**
 * The {@link https://api.playcanvas.com/classes/Engine.Script.html | Script} class is
 * the base class for all PlayCanvas scripts. Learn more about writing scripts in the
 * {@link https://developer.playcanvas.com/user-manual/scripting/ | scripting guide}.
 */
export class OnTriggerEnterShowPopup extends Script {

    static scriptName = 'onTriggerEnterShowPopup';

    /**
     * @attribute
     * @type {pc.Entity}
     * @title Html Handler Entity
     */
    htmlHandlerEntity;

    /**
     * Track when cart was last closed to prevent popup from opening immediately after
     */
    static lastCartCloseTime = 0;
    static cartCloseCooldown = 300; // milliseconds

    /**
     * Static registry to track popup elements and their observers
     * Maps popup element -> { observer, scriptInstance }
     */
    static popupRegistry = new Map();

    /**
     * Global flag to prevent cascading close events during bulk operations
     */
    static isClosingAll = false;

    /**
     * Reference to the currently open popup element
     */
    currentPopupElement = null;

    /**
     * MutationObserver for the current popup
     */
    currentPopupObserver = null;

    /**
     * Called when the script is about to run for the first time.
     */
    initialize() {
        // Listen for cart close events to track when cart closes
        this.setupCartCloseListener();
        
        // Listen for trigger enter event
        const triggerEnterEvent = TriggerTypes.EntitySubscribeTriggerEnter;
        this.entity.on(triggerEnterEvent, () => {
            // Check if cart is currently visible
            const cartRoot = document.getElementById('shopify-cart-root');
            if (cartRoot && cartRoot.style.display !== 'none') {
                console.log('[Popup] Cart is open, ignoring trigger enter to prevent popup from opening');
                return;
            }
            
            // Check if cart was just closed (within cooldown period)
            const timeSinceCartClose = Date.now() - OnTriggerEnterShowPopup.lastCartCloseTime;
            if (timeSinceCartClose < OnTriggerEnterShowPopup.cartCloseCooldown) {
                console.log(`[Popup] Cart was just closed ${timeSinceCartClose}ms ago, ignoring trigger enter to prevent popup from opening`);
                return;
            }
            
            // Close any existing popups before opening the new one
            // Don't fire close event since we're immediately opening a new one
            this.closeAllOpenPopups(false);
            
            this.showPopup();
        });

        // Listen for trigger leave event
        const triggerLeaveEvent = TriggerTypes.EntitySubscribeTriggerLeave;
        this.entity.on(triggerLeaveEvent, () => {
            this.hidePopup();
        });
    }

    /**
     * Shows the global modal backdrop to block background input
     */
    showBackdrop() {
        const backdrop = document.getElementById('ui-modal-backdrop');
        if (backdrop) backdrop.hidden = false;
    }

    /**
     * Hides the global modal backdrop to restore background input
     */
    hideBackdrop() {
        const backdrop = document.getElementById('ui-modal-backdrop');
        if (backdrop) backdrop.hidden = true;
    }

    /**
     * Closes all currently open popups
     * @param {boolean} fireCloseEvent - Whether to fire popup:close event (default: true)
     */
    closeAllOpenPopups(fireCloseEvent = true) {
        // Prevent re-entrancy and cascading events
        if (OnTriggerEnterShowPopup.isClosingAll) return;
        OnTriggerEnterShowPopup.isClosingAll = true;

        // Use registry as single source of truth - no CSS queries needed
        const popupsToClose = Array.from(OnTriggerEnterShowPopup.popupRegistry.keys());
        
        if (popupsToClose.length > 0) {
            console.log(`[Popup] Closing ${popupsToClose.length} existing popup(s) before opening new one`);
            
            // Disconnect all observers first to prevent them from firing events
            for (const popup of popupsToClose) {
                const entry = OnTriggerEnterShowPopup.popupRegistry.get(popup);
                if (entry?.observer) {
                    entry.observer.disconnect();
                }
                OnTriggerEnterShowPopup.popupRegistry.delete(popup);
                popup.style.display = "none";
            }
            
            this.hideBackdrop();
            if (fireCloseEvent) {
                this.app.fire('popup:close');
            }
        }

        OnTriggerEnterShowPopup.isClosingAll = false;
    }

    /**
     * Sets up listener for cart close events
     */
    setupCartCloseListener() {
        // Wait for cart to be available
        const checkCart = () => {
            const cartRoot = document.getElementById('shopify-cart-root');
            const cart = document.getElementById('shopify-cart');
            
            if (cartRoot && cart) {
                // Listen for cart close events
                const handleCartClose = () => {
                    OnTriggerEnterShowPopup.lastCartCloseTime = Date.now();
                    console.log('[OnTriggerEnterShowPopup] Cart closed, tracking timestamp to prevent popup opening');
                };
                
                cart.addEventListener('close', handleCartClose);
                cart.addEventListener('cart:close', handleCartClose);
                
                // Also watch for display changes on cart root
                const cartObserver = new MutationObserver((mutations) => {
                    mutations.forEach((mutation) => {
                        if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                            const cartRoot = document.getElementById('shopify-cart-root');
                            if (cartRoot && cartRoot.style.display === 'none') {
                                handleCartClose();
                            }
                        }
                    });
                });
                
                cartObserver.observe(cartRoot, { attributes: true, attributeFilter: ['style'] });
                
                // Watch shadow DOM dialog if available
                if (cart.shadowRoot) {
                    const dialog = cart.shadowRoot.querySelector('dialog');
                    if (dialog) {
                        dialog.addEventListener('close', handleCartClose);
                    }
                }
                
                console.log('[OnTriggerEnterShowPopup] Cart close listener set up');
            } else {
                // Retry after a short delay
                setTimeout(checkCart, 200);
            }
        };
        
        // Start checking after a short delay to allow cart to be injected
        setTimeout(checkCart, 500);
    }

    showPopup() {
        // Check if this entity has a ShopifyProductHandler script
        // If so, use that instead of the HTML handler approach
        const shopifyHandler = this.entity.script.shopifyProductHandler;
        if (shopifyHandler) {
            shopifyHandler.showProduct();
            
            // Find the popup element that was just shown
            const context = shopifyHandler.findShopifyContext();
            if (context) {
                const popupMenu = context.closest('.popup-menu') || 
                                 context.closest('[id^="popup-menu"]');
                if (popupMenu) {
                    // Store reference to current popup
                    this.currentPopupElement = popupMenu;
                    
                    // Show backdrop and fire events
                    this.showBackdrop();
                    this.app.fire('popup:open');
                    
                    // Set up observer to track when popup closes
                    this.currentPopupObserver = new MutationObserver(() => {
                        // Skip if we're in the middle of a bulk close operation
                        if (OnTriggerEnterShowPopup.isClosingAll) return;
                        
                        if (
                            popupMenu.style.display === 'none' ||
                            window.getComputedStyle(popupMenu).display === 'none'
                        ) {
                            // Only fire events if this popup is still registered to us
                            if (OnTriggerEnterShowPopup.popupRegistry.get(popupMenu)?.scriptInstance === this) {
                                this.hideBackdrop();
                                this.app.fire('popup:close');
                                this.currentPopupObserver.disconnect();
                                this.currentPopupObserver = null;
                                this.currentPopupElement = null;
                                OnTriggerEnterShowPopup.popupRegistry.delete(popupMenu);
                            }
                        }
                    });
                    
                    this.currentPopupObserver.observe(popupMenu, {
                        attributes: true,
                        attributeFilter: ['style']
                    });
                    
                    // Register this popup and observer
                    OnTriggerEnterShowPopup.popupRegistry.set(popupMenu, {
                        observer: this.currentPopupObserver,
                        scriptInstance: this
                    });
                    
                    // Optional: future-safe hook for <dialog> elements (doesn't fire for <div>)
                    const onClose = () => {
                        this.hideBackdrop();
                        this.app.fire('popup:close');
                        popupMenu.removeEventListener('close', onClose);
                        this.currentPopupElement = null;
                    };
                    popupMenu.addEventListener('close', onClose);
                }
            }
            return;
        }

        // Check if htmlHandlerEntity is properly configured
        if (!this.htmlHandlerEntity) {
            console.warn('[OnTriggerEnterShowPopup] htmlHandlerEntity is not set. Please configure it in the PlayCanvas editor.');
            return;
        }

        // Check for either htmlHandler or shopifyHtmlHandler
        const htmlHandler = this.htmlHandlerEntity.script?.htmlHandler || 
                           this.htmlHandlerEntity.script?.shopifyHtmlHandler;
        
        if (!htmlHandler) {
            console.warn('[OnTriggerEnterShowPopup] htmlHandlerEntity does not have an htmlHandler or shopifyHtmlHandler script attached.');
            return;
        }
        
        // For shopifyHtmlHandler, check htmlAssets first, then fall back to html
        let htmlAsset = htmlHandler.html;
        if (htmlHandler.htmlAssets && htmlHandler.htmlAssets.length > 0) {
            // Use the first HTML asset if htmlAssets is set
            htmlAsset = htmlHandler.htmlAssets[0];
        }
        
        if (!htmlAsset) {
            console.warn('[OnTriggerEnterShowPopup] htmlHandler.html or htmlHandler.htmlAssets is not set.');
            return;
        }

        const name = htmlAsset.name;
        const baseId = htmlHandler.removeHtmlExtensionRegex(name);
        
        // Check if handler supports uniquification (ShopifyHtmlHandler) or use original ID (HtmlHandler)
        let elementId = baseId;
        if (htmlHandler.getUniqueIdFor && typeof htmlHandler.getUniqueIdFor === 'function') {
            // ShopifyHtmlHandler - use uniquified ID
            elementId = htmlHandler.getUniqueIdFor(baseId);
        }
        // HtmlHandler - use original ID (already set to baseId)
        
        let element = document.getElementById(elementId);
        
        if (element) {
            element.style.display = "block";
            this.showBackdrop();
            
            // Store reference to current popup
            this.currentPopupElement = element;
            
            // Fire popup:open event for camera/input scripts to listen
            this.app.fire('popup:open');
            
            // Use MutationObserver as primary mechanism to detect closure
            this.currentPopupObserver = new MutationObserver(() => {
                // Skip if we're in the middle of a bulk close operation
                if (OnTriggerEnterShowPopup.isClosingAll) return;
                
                if (
                    element.style.display === 'none' ||
                    window.getComputedStyle(element).display === 'none'
                ) {
                    // Only fire events if this popup is still registered to us
                    if (OnTriggerEnterShowPopup.popupRegistry.get(element)?.scriptInstance === this) {
                        this.hideBackdrop();
                        this.app.fire('popup:close');
                        this.currentPopupObserver.disconnect();
                        this.currentPopupObserver = null;
                        this.currentPopupElement = null;
                        OnTriggerEnterShowPopup.popupRegistry.delete(element);
                    }
                }
            });
            
            this.currentPopupObserver.observe(element, {
                attributes: true,
                attributeFilter: ['style']
            });
            
            // Register this popup and observer
            OnTriggerEnterShowPopup.popupRegistry.set(element, {
                observer: this.currentPopupObserver,
                scriptInstance: this
            });
            
            // Optional: future-safe hook for <dialog> elements (doesn't fire for <div>)
            const onClose = () => {
                this.hideBackdrop();
                this.app.fire('popup:close');
                element.removeEventListener('close', onClose);
                this.currentPopupElement = null;
            };
            element.addEventListener('close', onClose);
        } else {
            console.warn(`[OnTriggerEnterShowPopup] Element with id "${elementId}" not found.`);
        }
    }

    hidePopup() {
        if (this.currentPopupElement) {
            // Disconnect observer before closing
            if (this.currentPopupObserver) {
                this.currentPopupObserver.disconnect();
                this.currentPopupObserver = null;
            }
            
            // Remove from registry
            OnTriggerEnterShowPopup.popupRegistry.delete(this.currentPopupElement);
            
            this.currentPopupElement.style.display = "none";
            this.hideBackdrop();
            this.app.fire('popup:close');
            this.currentPopupElement = null;
        } else {
            // Fallback: try to find and hide any open popups
            // Use registry if available, otherwise fall back to DOM query
            const openPopups = OnTriggerEnterShowPopup.popupRegistry.size > 0
                ? Array.from(OnTriggerEnterShowPopup.popupRegistry.keys())
                : document.querySelectorAll('.popup-menu[style*="block"]');
            
            if (openPopups.length > 0) {
                // Clean up registry entries
                for (const popup of openPopups) {
                    const entry = OnTriggerEnterShowPopup.popupRegistry.get(popup);
                    if (entry?.observer) {
                        entry.observer.disconnect();
                    }
                    OnTriggerEnterShowPopup.popupRegistry.delete(popup);
                    popup.style.display = "none";
                }
                
                this.hideBackdrop();
                this.app.fire('popup:close');
            }
        }
    }
}

