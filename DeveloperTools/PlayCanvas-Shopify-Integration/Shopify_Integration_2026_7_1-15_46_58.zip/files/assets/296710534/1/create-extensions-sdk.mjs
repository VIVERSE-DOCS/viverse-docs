
/**
 * version: v1.100.0
 * @namespace Create Extension SDK
 * @description The VIVERSE Create Extensions SDK provides developers with the capability to interact with the extended features of the VIVERSE platform, allowing them to integrate specific extension features through custom code to enhance the platform's flexibility and functionality.
 */
export const TriggerTypes = {
  Base: 'trigger:0',
  Echo: 'trigger:1',
  PCAppEventSubscribe: 'trigger:100001',
  NotificationCenterSubscribe: 'trigger:200001',
  NotificationCenterSubscribeEntityPicking: 'trigger:200002',
  TheatreJSSubscribe: 'trigger:210001',
  TheatreJSSubscribeSheetEnd: 'trigger:210002',
  EntitySubscribeAnimationEvent: 'trigger:300001',
  EntitySubscribeAnimationStart: 'trigger:300002',
  EntitySubscribeAnimationEnd: 'trigger:300003',
  EntitySubscribeCollisionStart: 'trigger:300004',
  EntitySubscribeCollisionEnd: 'trigger:300005',
  EntitySubscribeTriggerEnter: 'trigger:300006',
  EntitySubscribeTriggerLeave: 'trigger:300007',
  SitInSeat: 'trigger:300008',
  SharePhoto: 'trigger:400001',
  EnterAnyWorld: 'trigger:400002',
  EnterMyWorld: 'trigger:400003'
}

export const ActionTypes = {
  Base: 'action:0',
  Echo: 'action:1',
  PCAppEventPublish: 'action:100001',
  NotificationCenterPublish: 'action:200001',
  TheatreJSPublish: 'action:210001',
  TheatreJSPlaySheet: 'action:210002',
  EntityRigidbodyAddForceInPhysics: 'action:300001',
  EntityPlayAnimation: 'action:300002',
  EntityEnable: 'action:300003',
  EntityDisable: 'action:300004',
  EntityToggleEnabled: 'action:300005',
  EntityFadeIn: 'action:300006',
  EntityFadeOut: 'action:300007',
  EntityPlaySound: 'action:300008',
  EntityEnableCollision: 'action:300009',
  EntityDisableCollision: 'action:300010',
  EntityToggleCollision: 'action:300011',
  InworldNpcWaitingSpeak: 'action:300012',
  InworldNpcStopWaitingSpeak: 'action:300013',
  EntityEnableByTag: 'action:300014',
  EntityDisableByTag: 'action:300015',
  EntityCheckPoint: 'action:300016',
  EntityEnableById: 'action:300017',
  EntityDisableById: 'action:300018',
  EntityStopSound: 'action:3000019',
  EntityAssetUnload: 'action:3000020',
  EntityAssetReload: 'action:3000021',
  EntityDestroy: 'action:3000022',
  ParticleSystemPlay: 'action:3000023',
  Quest: 'action:400001',
  TeleportAvatar: 'action:400002',
  AssignUserAsset: 'action:400003',
  Vote: 'action:400004',
  ShowToastMessage: 'action:400005',
  TaskComplete: 'action:400006'
}


