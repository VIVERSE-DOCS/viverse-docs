import { Script } from 'playcanvas';

/**
 * Global wheel event blocker for popups.
 * Prevents wheel events from reaching PlayCanvas when popups are open.
 * 
 * Attach this script to any entity (e.g., same entity as HtmlHandler).
 * It will initialize once globally regardless of how many instances exist.
 */
export class PopupWheelBlocker extends Script {

    static scriptName = 'popupWheelBlocker';
    static isInitialized = false;

    /**
     * Called when the script is about to run for the first time.
     */
    initialize() {
        if (PopupWheelBlocker.isInitialized) {
            return; // Already set up globally
        }

        PopupWheelBlocker.isInitialized = true;
        this.setupWheelBlocker();
    }

    /**
     * Sets up the global wheel event blocker
     */
    setupWheelBlocker() {
        const canvas = this.app.graphicsDevice.canvas;

        const blockWheel = (e) => {
            const popupOpen =
                document.querySelector('.popup-menu[style*="block"]') ||
                document.querySelector('.popup-menu.active');

            if (!popupOpen) return;

            // Allow scrolling INSIDE popup
            if (popupOpen.contains(e.target)) return;

            e.preventDefault();
            e.stopImmediatePropagation();
        };

        // Capture phase is CRITICAL - intercepts BEFORE PlayCanvas
        document.addEventListener('wheel', blockWheel, { passive: false, capture: true });
        canvas.addEventListener('wheel', blockWheel, { passive: false, capture: true });

        console.log('[PopupWheelBlocker] Wheel blocker attached to document + canvas (capture phase)');
    }

    /**
     * Called for enabled (running state) scripts on each tick.
     * 
     * @param {number} dt - The delta time in seconds since the last frame.
     */
    update(dt) {
    }
}
