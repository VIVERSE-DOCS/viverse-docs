import { Script } from 'playcanvas';
import { ShopifyConfig } from './shopify-config.mjs';

/**
 * The {@link https://api.playcanvas.com/classes/Engine.Script.html | Script} class is
 * the base class for all PlayCanvas scripts. Learn more about writing scripts in the
 * {@link https://developer.playcanvas.com/user-manual/scripting/ | scripting guide}.
 */
export class InjectShopifyWebComponents extends Script {

    static scriptName = 'injectShopifyWebComponents';

    /**
     * Called when the script is about to run for the first time.
     */
    initialize() {
        this.injectShopify();
    }

    /**
     * Called for enabled (running state) scripts on each tick.
     * 
     * @param {number} dt - The delta time in seconds since the last frame.
     */
    update(dt) {
    }

    injectShopify() {
        // Check for JS script existence
        if (!document.querySelector('script[data-shopify-web-components]')) {
            const script = document.createElement('script');
            script.type = "module";
            script.src = ShopifyConfig.webComponentsCdnUrl;
            script.setAttribute("data-shopify-web-components", "true");

            document.head.appendChild(script);
            console.log("[Shopify] Web Components script injected.");
        } else {
            console.log("[Shopify] Script already exists — skipping.");
        }
    }
}