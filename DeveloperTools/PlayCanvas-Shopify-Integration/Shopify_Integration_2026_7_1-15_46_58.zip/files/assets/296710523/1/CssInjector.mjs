import { Script } from 'playcanvas';

/**
 * Injects multiple CSS assets into the document head as <style> tags.
 * Prevents duplicate injections by checking for existing styles.
 */
export class CssInjector extends Script {

    static scriptName = 'cssInjector';

    /**
     * Array of CSS assets to inject into the document head.
     * 
     * @attribute
     * @type {pc.Asset[]}
     * @title CSS Assets
     */
    cssAssets = [];

    /**
     * Called when the script is about to run for the first time.
     */
    initialize() {
        this.injectCss();
    }

    /**
     * Called for enabled (running state) scripts on each tick.
     * 
     * @param {number} dt - The delta time in seconds since the last frame.
     */
    update(dt) {
    }

    /**
     * Injects all CSS assets into the document head.
     */
    injectCss() {
        if (!this.cssAssets || this.cssAssets.length === 0) {
            return;
        }

        this.cssAssets.forEach((cssAsset, index) => {
            if (!cssAsset) {
                return;
            }

            const dataAttribute = `data-css-injector-${index}`;
            
            // Check if this CSS has already been injected
            if (!document.querySelector(`style[${dataAttribute}]`)) {
                const style = document.createElement('style');
                style.innerHTML = cssAsset.resource || '';
                style.setAttribute(dataAttribute, 'true');

                document.head.appendChild(style);
                console.log(`[CSS Injector] Stylesheet ${index + 1} injected: ${cssAsset.name || 'unnamed'}`);
            } else {
                console.log(`[CSS Injector] Stylesheet ${index + 1} already exists — skipping.`);
            }
        });
    }

    /**
     * Adds a CSS asset dynamically and injects it.
     * 
     * @param {pc.Asset} cssAsset - The CSS asset to inject
     */
    addCss(cssAsset) {
        if (!cssAsset) {
            console.warn("[CSS Injector] Cannot add empty CSS asset");
            return;
        }

        const index = this.cssAssets.length;
        this.cssAssets.push(cssAsset);
        
        const dataAttribute = `data-css-injector-${index}`;
        
        if (!document.querySelector(`style[${dataAttribute}]`)) {
            const style = document.createElement('style');
            style.innerHTML = cssAsset.resource || '';
            style.setAttribute(dataAttribute, 'true');

            document.head.appendChild(style);
            console.log(`[CSS Injector] Dynamic stylesheet injected: ${cssAsset.name || 'unnamed'}`);
        }
    }
}

