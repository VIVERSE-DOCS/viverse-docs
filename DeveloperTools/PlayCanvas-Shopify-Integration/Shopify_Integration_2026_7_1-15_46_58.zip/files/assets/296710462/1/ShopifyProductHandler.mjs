import { Script } from 'playcanvas';

/**
 * Handles dynamic product display for Shopify web components.
 * Updates the product handle in the shopify-context element.
 * Event-driven: no polling, uses events and MutationObserver.
 */
export class ShopifyProductHandler extends Script {

    static scriptName = 'shopifyProductHandler';

    /**
     * Product handle to display. Can be updated dynamically.
     * 
     * @attribute
     * @type {string}
     * @title Product Handle
     */
    productHandle = "";

    /**
     * Reference to the HtmlHandler entity that injects the HTML.
     * 
     * @attribute
     * @type {pc.Entity}
     * @title Html Handler Entity
     */
    htmlHandlerEntity;

    /**
     * Reference to the text entity that will display the product price.
     * 
     * @attribute
     * @type {pc.Entity}
     * @title Price Text Entity
     */
    priceTextEntity;

    /**
     * Format for displaying the price. Use {price} as placeholder.
     * 
     * @attribute
     * @type {string}
     * @title Price Format
     * @default {price}
     */
    priceFormat = "{price}";

    /**
     * Called when the script is about to run for the first time.
     */
    initialize() {
        // Wait for document.body to be available
        if (!document.body) {
            setTimeout(() => this.initialize(), 100);
            return;
        }

        // TASK 3: Use Promise-based injection instead of global events
        this.setupScopedBinding();
        
        // Price extraction will be set up in setupScopedBinding after popup root is available
    }

    /**
     * TASK 3: Sets up scoped binding using Promise from HtmlHandler
     * Replaces global shopify-html-ready event listener
     */
    setupScopedBinding() {
        // Get HtmlHandler reference
        let htmlHandler = null;
        
        if (this.htmlHandlerEntity && this.htmlHandlerEntity.script) {
            htmlHandler = this.htmlHandlerEntity.script.shopifyHtmlHandler || 
                         this.htmlHandlerEntity.script.htmlHandler;
        } else {
            // Try to find on same entity
            if (this.entity && this.entity.script) {
                htmlHandler = this.entity.script.shopifyHtmlHandler || 
                             this.entity.script.htmlHandler;
            }
        }

        if (!htmlHandler) {
            console.warn('[ShopifyProductHandler] HtmlHandler not found, will retry...');
            setTimeout(() => this.setupScopedBinding(), 200);
            return;
        }

        // Wait for popup injection Promise
        if (htmlHandler.injectPopupPromise) {
            htmlHandler.injectPopupPromise().then((popupRoot) => {
                if (popupRoot) {
                    this.popupRootEl = popupRoot;
                    console.log(`[ShopifyProductHandler] Popup root assigned for entity ${this.entity.getGuid()}`);
                    
                    // Find context within this popup root
                    const context = this.findShopifyContext();
                    if (context) {
                        this.bindProductHandleOnce(context);
                    } else {
                        // Set up scoped watcher if context not found yet
                        this.setupScopedContextWatcher();
                    }
                    
                    // ✅ FIX: Setup price extraction AFTER popup root is available
                    if (this.priceTextEntity) {
                        console.log('[ShopifyProductHandler] Setting up price extraction after popup root available');
                        this.setupPriceExtraction();
                    }
                } else {
                    console.warn('[ShopifyProductHandler] Popup root not available');
                }
            }).catch((error) => {
                console.error('[ShopifyProductHandler] Error waiting for popup injection:', error);
            });
        } else {
            // Fallback: try legacy approach
            console.warn('[ShopifyProductHandler] injectPopupPromise not available, using fallback');
            this.setupContextWatcher();
        }
    }

    /**
     * TASK 5: Scoped context watcher - only observes popupRootEl, not document.body
     */
    setupScopedContextWatcher() {
        if (!this.popupRootEl) {
            console.warn('[ShopifyProductHandler] No popupRootEl available for scoped watcher');
            return;
        }

        // Immediate check
        const context = this.findShopifyContext();
        if (context) {
            console.log('[ShopifyProductHandler] Context found immediately in popup root');
            this.bindProductHandleOnce(context);
            return; // Already bound, no need for observer
        }

        // TASK 5: Observe only within popupRootEl
        this.contextObserver = new MutationObserver((mutations) => {
            const context = this.findShopifyContext();
            if (context) {
                console.log('[ShopifyProductHandler] Context detected via scoped MutationObserver');
                this.bindProductHandleOnce(context);
                // TASK 5: Disconnect immediately after finding context
                this.contextObserver.disconnect();
            }
        });
        
        try {
            // TASK 5: Scope observer to popupRootEl only
            this.contextObserver.observe(this.popupRootEl, { childList: true, subtree: true });
            console.log('[ShopifyProductHandler] Scoped MutationObserver set up for popup root');
        } catch (error) {
            console.warn("[ShopifyProductHandler] Failed to setup scoped MutationObserver:", error);
        }

        // Fallback timeout to disconnect observer
        setTimeout(() => {
            if (this.contextObserver) {
                this.contextObserver.disconnect();
            }
        }, 5000);
    }

    /**
     * Legacy event-driven approach (fallback only)
     * @deprecated Use setupScopedBinding() instead
     */
    setupContextWatcher() {
        console.warn('[ShopifyProductHandler] Using legacy setupContextWatcher - consider using setupScopedBinding');
        
        // Immediate check
        const context = this.findShopifyContext();
        if (context) {
            console.log('[ShopifyProductHandler] Context found immediately, setting handle');
            this.bindProductHandleOnce(context);
        } else {
            console.log('[ShopifyProductHandler] Context not found yet, setting up watchers');
        }

        // Use MutationObserver to catch context when it's added to DOM
        this.contextObserver = new MutationObserver((mutations) => {
            const context = this.findShopifyContext();
            if (context) {
                console.log('[ShopifyProductHandler] Context detected via MutationObserver');
                this.bindProductHandleOnce(context);
                this.contextObserver.disconnect();
            }
        });
        
        try {
            // Use popupRootEl if available, otherwise fallback to document.body
            const observeTarget = this.popupRootEl || document.body;
            this.contextObserver.observe(observeTarget, { childList: true, subtree: true });
        } catch (error) {
            console.warn("[ShopifyProductHandler] Failed to setup context MutationObserver:", error);
        }
    }

    /**
     * TASK 4: Bind product handle exactly ONCE per popup
     * Prevents repeated handle writes that cause GraphQL argument conflicts
     */
    bindProductHandleOnce(context) {
        if (!context) {
            return;
        }

        // TASK 4: Guard to prevent multiple bindings
        if (this._handleBound) {
            console.log(`[ShopifyProductHandler] Handle already bound for entity ${this.entity.getGuid()}, skipping`);
            return;
        }

        // TASK 8: Validate product handle
        if (!this.productHandle || this.productHandle.trim() === '') {
            console.warn("[ShopifyProductHandler] productHandle is empty. Set it in the PlayCanvas editor or use setProductHandle().");
            return;
        }

        // TASK 8: Validate handle format (no special characters, lowercase preferred)
        const handle = this.productHandle.trim();
        if (handle === 'placeholder-product') {
            console.warn("[ShopifyProductHandler] productHandle is still placeholder-product");
            return;
        }

        // Set handle once
        context.setAttribute('handle', handle);
        this._handleBound = true;
        
        const entityId = this.popupRootEl ? 
            this.popupRootEl.getAttribute('data-shopify-entity-id') : 
            this.entity.getGuid();
        console.log(`[ShopifyProductHandler] ✅ Bound handle "${handle}" ONCE for entity ${entityId}`);
    }

    /**
     * Legacy method (kept for backward compatibility)
     * @deprecated Use bindProductHandleOnce() instead
     */
    setHandleOnContext(context) {
        this.bindProductHandleOnce(context);
    }

    /**
     * Event-driven price extraction. Waits for price to appear, then extracts it once.
     */
    setupPriceExtraction() {
        if (!this.popupRootEl) {
            console.warn('[ShopifyProductHandler] setupPriceExtraction called but popupRootEl not set yet');
            return;
        }
        if (!this.priceTextEntity) {
            return;
        }

        if (this._priceExtractionSetup) {
            this.checkAndExtractPrice();
            return;
        }
        this._priceExtractionSetup = true;
        this._htmlReadyForPrice = false;
        this._componentsReadyForPrice = false;

        this._markHtmlReadyForPrice = (reason) => {
            if (this._htmlReadyForPrice) {
                return;
            }
            this._htmlReadyForPrice = true;
            console.log('[ShopifyProductHandler] htmlReady set to true:', reason);
            this.checkAndExtractPrice();
        };

        this._markComponentsReadyForPrice = (reason) => {
            if (this._componentsReadyForPrice) {
                return;
            }
            this._componentsReadyForPrice = true;
            console.log('[ShopifyProductHandler] componentsReady set to true:', reason);
            this._cleanupComponentsReadyWait?.();
            this.checkAndExtractPrice();
        };

        this._onShopifyHtmlReady = () => {
            this._markHtmlReadyForPrice('shopifyHtmlReady app event');
        };
        this.app.on('shopifyHtmlReady', this._onShopifyHtmlReady);

        if (this.popupRootEl.querySelector('shopify-context')) {
            this._markHtmlReadyForPrice('context found in popup root');
        }

        this._onComponentsReadyForPrice = () => {
            this._markComponentsReadyForPrice('shopify-components-ready event');
        };
        window.addEventListener('shopify-components-ready', this._onComponentsReadyForPrice);

        this._cleanupComponentsReadyWait = () => {
            if (this._onComponentsReadyForPrice) {
                window.removeEventListener('shopify-components-ready', this._onComponentsReadyForPrice);
                this._onComponentsReadyForPrice = null;
            }
            if (this._componentsReadyPollInterval) {
                clearInterval(this._componentsReadyPollInterval);
                this._componentsReadyPollInterval = null;
            }
        };

        const checkComponentsReady = () => {
            if (window.Shopify?.webComponents?.initialized) {
                return 'Shopify.webComponents.initialized';
            }
            if (customElements.get('shopify-context')) {
                return 'shopify-context custom element registered';
            }
            return null;
        };

        const initialReason = checkComponentsReady();
        if (initialReason) {
            this._markComponentsReadyForPrice(initialReason);
        } else {
            let pollCount = 0;
            const maxPolls = 20;
            this._componentsReadyPollInterval = setInterval(() => {
                pollCount++;
                const reason = checkComponentsReady();
                if (reason) {
                    this._markComponentsReadyForPrice(reason);
                    return;
                }

                const context = this.findShopifyContext();
                if (context?.product != null) {
                    this._markComponentsReadyForPrice('context.product hydrated');
                    return;
                }

                if (pollCount >= maxPolls) {
                    this._cleanupComponentsReadyWait();
                    if (context) {
                        this._markComponentsReadyForPrice('fallback timeout with product context present');
                    } else {
                        console.warn('[ShopifyProductHandler] Components readiness timeout - price extraction may fail');
                    }
                }
            }, 500);
        }

        console.log('[ShopifyProductHandler] setupPriceExtraction - initial check');
        this.checkAndExtractPrice();
    }

    /**
     * Attempts price extraction once HTML and Shopify components are ready.
     */
    checkAndExtractPrice() {
        if (!this._htmlReadyForPrice || !this._componentsReadyForPrice) {
            if (!this._priceNotReadyLogged) {
                this._priceNotReadyLogged = true;
                console.log('[ShopifyProductHandler] checkAndExtractPrice - not ready yet:', {
                    htmlReady: this._htmlReadyForPrice,
                    componentsReady: this._componentsReadyForPrice,
                    hasPopupRoot: !!this.popupRootEl
                });
            }
            return;
        }

        const context = this.findShopifyContext();
        if (!context) {
            console.log('[ShopifyProductHandler] ⚠️ Context not found for price extraction');
            return;
        }

        console.log('[ShopifyProductHandler] 🔍 Searching for price in context:', {
            contextId: context.id || 'no-id',
            handle: context.getAttribute('handle'),
            childrenCount: context.children.length,
            allMoneyElements: context.querySelectorAll('shopify-money').length,
            moneyWithPriceQuery: context.querySelectorAll('shopify-money[query*="price"]').length
        });

        const priceElement = context.querySelector('shopify-money[query*="price"]');

        if (priceElement) {
            console.log('[ShopifyProductHandler] ✅ Found price element:', {
                query: priceElement.getAttribute('query'),
                textContent: priceElement.textContent?.trim(),
                innerHTML: priceElement.innerHTML?.substring(0, 100),
                hasShadowRoot: !!priceElement.shadowRoot
            });
        } else {
            console.warn('[ShopifyProductHandler] ⚠️ Price element NOT found with selector shopify-money[query*="price"]');
            const allMoney = context.querySelectorAll('shopify-money');
            if (allMoney.length > 0) {
                console.log('[ShopifyProductHandler] Found shopify-money elements (but not matching price query):');
                allMoney.forEach((el, idx) => {
                    console.log(`  [${idx}] query="${el.getAttribute('query')}", text="${el.textContent?.trim()?.substring(0, 30)}"`);
                });
            }
        }

        if (!priceElement) {
            const priceWatcher = new MutationObserver(() => {
                const priceEl = context.querySelector('shopify-money[query*="price"]');
                if (priceEl) {
                    console.log('[ShopifyProductHandler] ✅ Price element found via MutationObserver');
                    this.extractPriceOnce(priceEl);
                    priceWatcher.disconnect();
                }
            });
            priceWatcher.observe(context, { childList: true, subtree: true });

            setTimeout(() => {
                priceWatcher.disconnect();
            }, 5000);
            return;
        }

        const priceText = this.extractPriceText(priceElement);
        console.log('[ShopifyProductHandler] 💰 Extracted price text:', priceText || '(null/empty)');

        if (priceText) {
            this.updatePriceText(priceText);
        } else {
            console.warn('[ShopifyProductHandler] ⚠️ Price element found but extractPriceText returned null/empty. Setting up watcher...');
            this.watchForPriceContent(priceElement);
        }
    }

    /**
     * Watches for price content to appear in the price element.
     * Uses MutationObserver to detect when text content is added.
     */
    watchForPriceContent(priceElement) {
        // Check immediately first
        const initialPrice = this.extractPriceText(priceElement);
        if (initialPrice) {
            this.updatePriceText(initialPrice);
            return;
        }

        // Watch for content changes
        const observer = new MutationObserver(() => {
            const priceText = this.extractPriceText(priceElement);
            if (priceText) {
                this.updatePriceText(priceText);
                observer.disconnect();
            }
        });

        observer.observe(priceElement, {
            childList: true,
            subtree: true,
            characterData: true
        });

        // Store for cleanup
        this.priceObserver = observer;

        // Fallback timeout
        setTimeout(() => {
            observer.disconnect();
        }, 10000);
    }

    /**
     * Extracts price once when element is ready. No continuous monitoring.
     */
    extractPriceOnce(priceElement) {
        const priceText = this.extractPriceText(priceElement);
        if (priceText) {
            this.updatePriceText(priceText);
        } else {
            // Element exists but no content yet, watch for it
            this.watchForPriceContent(priceElement);
        }
    }

    /**
     * TASK 2: Finds the shopify-context element within this entity's popup root ONLY
     * No document-level queries - strictly scoped to popupRootEl
     * 
     * @returns {HTMLElement|null} The shopify-context element or null if not found
     */
    findShopifyContext() {
        // TASK 2: MUST query within popupRootEl - no document queries
        if (!this.popupRootEl) {
            console.warn('[ShopifyProductHandler] No popupRootEl available - cannot find context');
            return null;
        }

        // TASK 2: Query inside popupRootEl only
        const context = this.popupRootEl.querySelector('shopify-context[type="product"]');
        
        if (context) {
            const entityId = this.popupRootEl.getAttribute('data-shopify-entity-id');
            console.log(`[ShopifyProductHandler] Found context in popup root for entity ${entityId}`);
            return context;
        }

        // Debug: log what's in popup root
        const allContexts = this.popupRootEl.querySelectorAll('shopify-context');
        if (allContexts.length > 0) {
            console.warn('[ShopifyProductHandler] Contexts found in popup root but none with type="product":', 
                Array.from(allContexts).map(ctx => ({
                    id: ctx.id,
                    handle: ctx.getAttribute('handle'),
                    type: ctx.getAttribute('type')
                }))
            );
        } else {
            console.warn('[ShopifyProductHandler] No shopify-context elements found in popup root');
        }
        
        return null;
    }

    /**
     * Extracts the price text from a shopify-money element.
     * 
     * @param {HTMLElement} priceElement - The shopify-money element
     * @returns {string|null} The price text or null if not found
     */
    extractPriceText(priceElement) {
        if (!priceElement) {
            console.warn('[ShopifyProductHandler] extractPriceText called with null element');
            return null;
        }

        // Try to get text content directly
        let priceText = priceElement.textContent?.trim();
        console.log('[ShopifyProductHandler] extractPriceText - direct textContent:', priceText || '(empty)');
        
        if (!priceText && priceElement.shadowRoot) {
            // If it's in shadow DOM, try to access it
            priceText = priceElement.shadowRoot.textContent?.trim();
            console.log('[ShopifyProductHandler] extractPriceText - shadowRoot.textContent:', priceText || '(empty)');
        }

        // Also check for the formatted price in the element
        if (!priceText) {
            const formattedElement = priceElement.querySelector('.shopify-money') || 
                                   priceElement.querySelector('[class*="price"]');
            if (formattedElement) {
                priceText = formattedElement.textContent?.trim();
                console.log('[ShopifyProductHandler] extractPriceText - formattedElement.textContent:', priceText || '(empty)');
            } else {
                console.log('[ShopifyProductHandler] extractPriceText - no formattedElement found');
            }
        }

        const result = priceText || null;
        console.log('[ShopifyProductHandler] extractPriceText - final result:', result);
        return result;
    }

    /**
     * Updates the PlayCanvas text entity with the price.
     * 
     * @param {string} priceText - The price text to display
     */
    updatePriceText(priceText) {
        if (!this.priceTextEntity || !this.priceTextEntity.element) {
            return;
        }

        // Remove quotes (both single and double) from the price text
        const cleanPriceText = priceText.replace(/['"]/g, '');

        // Format the price if a format string is provided
        const formattedPrice = this.priceFormat.replace('{price}', cleanPriceText);
        
        // Update the text entity
        this.priceTextEntity.element.text = formattedPrice;
        
        console.log(`[Shopify] Price updated: ${formattedPrice}`);
    }

    /**
     * Shows the product popup with this entity's product handle.
     * Call this when the product entity is clicked/selected.
     */
    showProduct() {
        if (!this.productHandle) {
            console.warn("[Shopify] Cannot show product: productHandle is empty");
            return;
        }

        // Update the context with this product's handle
        this.setProductHandle(this.productHandle);
        
        // Find and show the popup menu
        const context = this.findShopifyContext();
        if (context) {
            const popupMenu = context.closest('.popup-menu') || 
                             context.closest('[id^="popup-menu"]');
            if (popupMenu) {
                popupMenu.style.display = 'block';
                console.log(`[Shopify] Showing popup for product: ${this.productHandle}`);
            }
        }
    }

    /**
     * Sets the product handle and updates the shopify-context element.
     * Can be called from other scripts or triggered by events.
     * 
     * @param {string} handle - The product handle to display
     */
    setProductHandle(handle) {
        if (!handle) {
            console.warn("[Shopify] Product handle is empty");
            return;
        }

        // TASK 8: Validate handle
        const validatedHandle = handle.trim();
        if (validatedHandle === 'placeholder-product') {
            console.warn("[Shopify] Cannot set handle to placeholder-product");
            return;
        }

        this.productHandle = validatedHandle;

        // If already bound, don't rebind (TASK 4)
        if (this._handleBound) {
            const context = this.findShopifyContext();
            if (context) {
                context.setAttribute('handle', validatedHandle);
                console.log(`[Shopify] Product handle updated to: ${validatedHandle} (handle was already bound)`);
            }
            return;
        }

        // If popup root not ready, wait for it
        if (!this.popupRootEl) {
            console.log("[Shopify] Popup root not ready, will bind when available");
            // setupScopedBinding will handle binding when ready
            return;
        }

        const context = this.findShopifyContext();
        if (context) {
            this.bindProductHandleOnce(context);
        } else {
            console.warn("[Shopify] shopify-context element not found in popup root");
            // Set up watcher if not already watching
            if (!this.contextObserver) {
                this.setupScopedContextWatcher();
            }
        }
    }

    /**
     * Gets the current product handle.
     * 
     * @returns {string} The current product handle
     */
    getProductHandle() {
        return this.productHandle;
    }

    /**
     * Sets the price text entity reference.
     * 
     * @param {pc.Entity} entity - The text entity to update
     */
    setPriceTextEntity(entity) {
        this.priceTextEntity = entity;
        // If entity is set after initialization, set up price extraction
        if (entity) {
            this.setupPriceExtraction();
        }
    }

    /**
     * TASK 7: Cleanup when script is destroyed
     */
    destroy() {
        if (this.priceObserver) {
            this.priceObserver.disconnect();
        }
        if (this.contextObserver) {
            this.contextObserver.disconnect();
        }

        if (this._onShopifyHtmlReady) {
            this.app.off('shopifyHtmlReady', this._onShopifyHtmlReady);
            this._onShopifyHtmlReady = null;
        }
        this._cleanupComponentsReadyWait?.();

        this._handleBound = false;
        this._priceExtractionSetup = false;
        this._htmlReadyForPrice = false;
        this._componentsReadyForPrice = false;
        this._priceNotReadyLogged = false;
        this.popupRootEl = null;

        console.log(`[ShopifyProductHandler] Cleaned up for entity ${this.entity.getGuid()}`);
    }
}
