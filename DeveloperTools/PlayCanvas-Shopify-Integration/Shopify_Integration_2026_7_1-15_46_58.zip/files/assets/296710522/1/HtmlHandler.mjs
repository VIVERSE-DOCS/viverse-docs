import { Script } from 'playcanvas';

/**
 * The {@link https://api.playcanvas.com/classes/Engine.Script.html | Script} class is
 * the base class for all PlayCanvas scripts. Learn more about writing scripts in the
 * {@link https://developer.playcanvas.com/user-manual/scripting/ | scripting guide}.
 */
export class HtmlHandler extends Script {

    static scriptName = 'htmlHandler';

    /**
     * Multiple HTML assets that will be injected into <div> elements in the document body.
     * 
     * @attribute
     * @type {pc.Asset[]}
     * @title HTML Assets (Array)
     */
    htmlAssets = [];

    /**
     * Gets the HTML assets array
     * @returns {pc.Asset[]} Array of HTML assets
     */
    getHtmlAssets() {
        if (this.htmlAssets && this.htmlAssets.length > 0) {
            return Array.isArray(this.htmlAssets) ? this.htmlAssets : [this.htmlAssets];
        }
        return [];
    }

     /**
     * Called when the script is about to run for the first time.
     */
    initialize() {
        // Collect HTML assets
        const htmlAssets = this.getHtmlAssets();
        
        if (htmlAssets.length === 0) {
            console.warn('[HtmlHandler] No HTML assets configured');
            return;
        }

        // Create main container div
        this.div = document.createElement('div');
        
        // Track injection status
        this.htmlInjectionStatus = new Map();
        htmlAssets.forEach(asset => {
            if (asset && asset.name) {
                this.htmlInjectionStatus.set(asset.name, false);
            }
        });

        // Inject all HTML assets (NO uniquification - use IDs as-is from HTML files)
        htmlAssets.forEach((htmlAsset, index) => {
            if (!htmlAsset || !htmlAsset.resource) {
                console.warn(`[HtmlHandler] HTML asset at index ${index} is missing or has no resource`);
                return;
            }

            const htmlContent = htmlAsset.resource || '';
            
            // Create a div for this HTML asset
            const assetDiv = document.createElement('div');
            assetDiv.setAttribute('data-html-asset', htmlAsset.name);
            
            // Use HTML content as-is (no uniquification)
            assetDiv.innerHTML = htmlContent;
            
            this.div.appendChild(assetDiv);
            
            // Mark as injected
            if (htmlAsset.name) {
                this.htmlInjectionStatus.set(htmlAsset.name, true);
            }
        });

        this.waitForCanvasUI();
    }

    /**
     * Called for enabled (running state) scripts on each tick.
     * 
     * @param {number} dt - The delta time in seconds since the last frame.
     */
    update(dt) {
    }

    bindEvents() {
        // Get HTML assets
        const htmlAssets = this.getHtmlAssets();
        
        // Bind events for each HTML asset using original IDs (not uniquified)
        htmlAssets.forEach(htmlAsset => {
            if (!htmlAsset) return;
            
            const baseId = this.removeHtmlExtensionRegex(htmlAsset.name);
            const modal = document.getElementById(baseId); // Use original ID directly
            
            if (modal) {
                const span = modal.getElementsByClassName('close-button')[0];
                if (span) {
                    span.onclick = function() {
                        modal.style.display = "none";
                    }
                }
            }
        });
        
        // Remove data-shopify-action attributes to prevent Shopify from adding inline handlers
        this.removeShopifyActionAttributes(this.div);
        
        // Set up MutationObserver to catch buttons rendered by Shopify templates
        this.setupShopifyButtonObserver(this.div);
        
        // Bind Shopify button events on the injected div container
        this.bindShopifyEvents(this.div);
    }

    /**
     * Removes data-shopify-action attributes to prevent Shopify from adding inline handlers.
     * Stores the action value in a custom attribute for our event handler.
     * 
     * @param {HTMLElement} container - The container element to search within
     */
    removeShopifyActionAttributes(container) {
        if (!container) return;

        // Find all buttons with data-shopify-action and replace with custom attribute
        const buttons = container.querySelectorAll('[data-shopify-action]');
        buttons.forEach(button => {
            const action = button.getAttribute('data-shopify-action');
            if (action) {
                // Remove the attribute that Shopify uses to add inline handlers
                button.removeAttribute('data-shopify-action');
                // Store in custom attribute for our event handler
                button.setAttribute('data-custom-shopify-action', action);
            }
        });
    }

    /**
     * Sets up a MutationObserver to watch for buttons rendered by Shopify templates
     * and remove data-shopify-action attributes as they're added to the DOM.
     * 
     * @param {HTMLElement} container - The container element to observe
     */
    setupShopifyButtonObserver(container) {
        if (!container) return;

        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) { // Element node
                        // Check if the added node itself has the attribute
                        if (node.hasAttribute && node.hasAttribute('data-shopify-action')) {
                            const action = node.getAttribute('data-shopify-action');
                            if (action) {
                                node.removeAttribute('data-shopify-action');
                                node.setAttribute('data-custom-shopify-action', action);
                            }
                        }
                        // Check for buttons within the added node
                        if (node.querySelectorAll) {
                            const buttons = node.querySelectorAll('[data-shopify-action]');
                            buttons.forEach(button => {
                                const action = button.getAttribute('data-shopify-action');
                                if (action) {
                                    button.removeAttribute('data-shopify-action');
                                    button.setAttribute('data-custom-shopify-action', action);
                                }
                            });
                        }
                    }
                });
            });
        });

        observer.observe(container, {
            childList: true,
            subtree: true
        });

        // Store observer for cleanup
        this.shopifyButtonObserver = observer;
    }

    /**
     * Binds event listeners to Shopify buttons using data attributes.
     * Replaces inline onclick handlers for CSP compliance.
     * 
     * @param {HTMLElement} container - The container element to search within
     */
    bindShopifyEvents(container) {
        if (!container) return;

        // Use event delegation to handle clicks on Shopify buttons
        // We removed data-shopify-action attributes, so Shopify won't add inline handlers
        container.addEventListener('click', (event) => {
            const button = event.target.closest('[data-custom-shopify-action]');
            if (!button) return;

            // Only prevent default if we're handling it (to avoid any default button behavior)
            event.preventDefault();
            event.stopPropagation();

            const action = button.getAttribute('data-custom-shopify-action');

            switch (action) {
                case 'view-product': {
                    // Use querySelector strategies instead of uniquified IDs
                    const popupMenu = button.closest('.popup-menu');
                    const productModal = popupMenu ? popupMenu.querySelector('.product-modal') : 
                                         document.querySelector('.product-modal');
                    const context = productModal ? 
                                   productModal.querySelector('shopify-context[wait-for-update]') :
                                   document.querySelector('shopify-context[wait-for-update]');
                    
                    // Get the product handle from the source context
                    // The button might be in a shadow DOM, so we need to traverse up
                    let sourceContext = button.closest('shopify-context');
                    if (!sourceContext) {
                        // Try finding the context by going up the DOM tree
                        let parent = button.parentElement;
                        while (parent && !sourceContext) {
                            if (parent.tagName === 'SHOPIFY-CONTEXT') {
                                sourceContext = parent;
                            } else {
                                parent = parent.parentElement;
                            }
                        }
                    }
                    
                    const handle = sourceContext ? sourceContext.getAttribute('handle') : null;
                    
                    console.log('[HtmlHandler] View product clicked, handle:', handle, 'modal:', productModal, 'context:', context);
                    
                    if (productModal) {
                        productModal.showModal();
                    }
                    
                    if (context) {
                        // Set the handle on the modal context first
                        if (handle && handle !== 'placeholder-product') {
                            context.setAttribute('handle', handle);
                            console.log('[HtmlHandler] Set handle on modal context:', handle);
                        }
                        
                        // Call update method if available
                        // Shopify's update method may need the event to extract product info
                        if (typeof context.update === 'function') {
                            try {
                                // Pass the original event - it should be safe since we removed data-shopify-action
                                context.update(event);
                                console.log('[HtmlHandler] Called context.update with event');
                            } catch (error) {
                                console.error('[HtmlHandler] Error calling context.update:', error);
                                // Fallback: just ensure handle is set
                                if (handle && handle !== 'placeholder-product') {
                                    context.setAttribute('handle', handle);
                                }
                            }
                        } else if (handle && handle !== 'placeholder-product') {
                            // If update method doesn't exist, just set the handle
                            context.setAttribute('handle', handle);
                        }
                    } else {
                        console.warn('[HtmlHandler] Modal context not found');
                    }
                    break;
                }

                case 'close-modal': {
                    const modal = button.closest('.product-modal');
                    if (modal) {
                        modal.close();
                    }
                    break;
                }

                case 'add-to-cart': {
                    const popupMenu = button.closest('.popup-menu');
                    const cart = popupMenu ? popupMenu.querySelector('shopify-cart') :
                                 document.querySelector('shopify-cart');
                    
                    if (cart && cart.addLine) {
                        try {
                            const result = cart.addLine(event);
                            if (result && typeof result.showModal === 'function') {
                                result.showModal();
                            } else if (cart.showModal) {
                                cart.showModal();
                            }
                        } catch (error) {
                            console.error('[HtmlHandler] Error adding to cart:', error);
                        }
                    }
                    break;
                }

                case 'buy-now': {
                    const store = document.querySelector('shopify-store');
                    if (store && store.buyNow) {
                        try {
                            store.buyNow(event);
                        } catch (error) {
                            console.error('[HtmlHandler] Error with buy now:', error);
                        }
                    }
                    break;
                }

                case 'view-cart': {
                    const popupMenu = button.closest('.popup-menu');
                    const cart = popupMenu ? popupMenu.querySelector('shopify-cart') :
                                 document.querySelector('shopify-cart');
                    
                    if (cart && cart.showModal) {
                        try {
                            cart.showModal();
                        } catch (error) {
                            console.error('[HtmlHandler] Error opening cart:', error);
                        }
                    }
                    break;
                }
            }
        });
    }

    removeHtmlExtensionRegex(filename) {
        return filename.replace(/\.html$/, ''); 
    }

    waitForCanvasUI(retryDelay = 200) {
        var worldRoot = document.getElementById('canvas-wrapper');

        if (worldRoot == null) {
            setTimeout(() => this.waitForCanvasUI(retryDelay), retryDelay);
        }
        else {
            worldRoot.appendChild(this.div);
            this.handleInjectionComplete();
        }
    }

    /**
     * Handles completion of HTML injection
     */
    handleInjectionComplete() {
        // Mark all HTML assets as injected
        const htmlAssets = this.getHtmlAssets();
        htmlAssets.forEach(asset => {
            if (asset && asset.name) {
                this.htmlInjectionStatus.set(asset.name, true);
            }
        });
        
        this.bindEvents();
    }

    /**
     * Cleanup when script is destroyed.
     */
    destroy() {
        if (this.shopifyButtonObserver) {
            this.shopifyButtonObserver.disconnect();
        }
    }
}