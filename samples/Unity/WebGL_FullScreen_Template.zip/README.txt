Unity WebGL Fullscreen Template
================================

This package contains a ready-to-use fullscreen WebGL template for Unity projects
targeting VIVERSE or any WebGL deployment.

INSTALLATION
------------

1. Extract this ZIP file to a temporary location

2. Copy the "FullScreen" folder to your Unity project:
   - Navigate to your Unity project's Assets folder
   - Copy the "FullScreen" folder into: Assets/WebGLTemplates/
   - Final path should be: Assets/WebGLTemplates/FullScreen/

3. Refresh Unity:
   - Press Ctrl+R (Windows) or Cmd+R (Mac)
   - Or right-click in Project window → Refresh

4. Select the template in Build Settings:
   - Go to File → Build Settings
   - Click "Player Settings..."
   - Navigate to Publishing Settings
   - Under "WebGL Template", select "FullScreen" from the dropdown

5. Build your WebGL project!

FEATURES
--------

- Fullscreen canvas (fills entire browser viewport on desktop and mobile)
- Custom loading screen with progress bar
- Mobile: viewport meta tag, full-viewport fixed layout, canvas sized to 100% via CSS, and devicePixelRatio clamped to 1 to reduce WebGL backing-store / VRAM pressure on high-DPI phones (helps VIVERSE-style mobile clients)
- Error/warning banner support
- Unity template variable support (product name, version, etc.)
- Optimized for VIVERSE deployment

CUSTOMIZATION
-------------

Loading Screen Images:
- The template references Unity's default loading images:
  * unity-logo-dark.png (154×130px)
  * progress-bar-empty-dark.png (141×18px)
  * progress-bar-full-dark.png (141×18px)

- To use custom images:
  1. Place your custom images in the FullScreen folder
  2. Update the image filenames in index.html (CSS section)
  3. Or modify the CSS to use HTML/CSS-based loading screens

Background Color:
- Edit the #unity-canvas background color in the <style> section
- Default: #231F20 (dark gray)

TROUBLESHOOTING
---------------

Template not appearing in Build Settings:
- Ensure folder is named exactly "WebGLTemplates" (case-sensitive)
- Ensure index.html is directly in Assets/WebGLTemplates/FullScreen/
- Refresh Unity project (Ctrl+R / Cmd+R)
- Restart Unity Editor if needed

Loading screen not showing:
- Check browser console for JavaScript errors (F12)
- Verify image paths in CSS are correct
- Ensure Unity's default template images are present (or update paths)

Fullscreen not working:
- Desktop: canvas width/height are set to 100% in JavaScript; html/body should fill the viewport (see index.html).
- Mobile: if you see a small canvas or black bars, keep the #unity-container.unity-mobile and .unity-mobile #unity-canvas rules in index.html.
- Mobile crashes or heavy GPU use: the template sets devicePixelRatio to 1 on mobile; do not remove that if targeting phones.
- Test in different browsers (Chrome, Firefox, Edge)
- Some browsers require user interaction before allowing fullscreen

SUPPORT
-------

For more information, see:
- Unity WebGL Documentation: https://docs.unity3d.com/Manual/webgl.html
- VIVERSE Developer Portal: https://worlds.viverse.com/

